# HELLCORE CORE 0.6 — Build and validation report

Date: 2026-11-15  
Target: x86-64 freestanding C++20 kernel, native UEFI PE32+ loader

## Implemented

- Corrected AHCI per-port command-slot selection and IDENTIFY capacity parsing.
- Added synchronous, single-sector AHCI DMA read/write APIs using READ DMA EXT / WRITE DMA EXT. Buffers must be 512-byte aligned, physically contiguous, identity-mapped and below 4 GiB.
- Added PCI bus-master enable/readback and wired it into AHCI, E1000 and xHCI controller bring-up.
- Added E1000 32-entry TX/RX descriptor rings, DMA buffers, ring programming and basic send/receive APIs.
- Retained xHCI controller halt/reset probing. USB enumeration is not implemented.

## Build and host tests actually run

Command:

```sh
make clean all efi esp check
nm -u build/kernel.elf
```

Results:

- Freestanding kernel compilation and static ELF64 link: PASS.
- Native UEFI loader compilation and PE32+ link: PASS.
- EFI system partition directory generation: PASS.
- ACPI parser tests: PASS.
- PCI resource allocator and PCI class tests: PASS.
- PMM host tests: PASS.
- ELF and UEFI PE32+ format/ABI checks: PASS.
- Undefined kernel symbols: none reported.

## QEMU/UEFI runtime validation

**BLOCKED — NOT RUN.** `scripts/validate-boot.sh` exited with status 2:

```text
BOOT BLOCKED: qemu-system-x86_64 is not installed. Install qemu-system-x86 and ovmf, then rerun.
```

An `apt-get update` attempt timed out. No QEMU process ran, OVMF was unavailable, and no serial boot log was produced. Consequently, this release is not honestly described as runtime-verified, and no AHCI/E1000/xHCI runtime success is claimed.

## Driver maturity and limitations

- AHCI is a synchronous one-sector DMA prototype; no multi-sector batching, NCQ, interrupt-driven completion, timeout recovery, hotplug, DMA allocator, block layer or filesystem. Caller buffers must meet the documented DMA constraints.
- E1000 has basic descriptor-ring TX/RX APIs but has not been tested against QEMU or physical hardware. No interrupt path, robust error recovery, multi-revision support or network stack is present. Only one controller is initialized.
- xHCI remains halt/reset only: no command/event/transfer rings, slot/context setup, enumeration, control transfers or HID.
- BAR relocation is not automatically enabled because validated host-bridge apertures are not discovered. MMIO and DMA paths remain limited below 4 GiB; no IOMMU support.

## Next validation gates

1. Install QEMU x86-64 and OVMF; run `scripts/validate-boot.sh` and retain `build/logs/serial.log`.
2. Test AHCI IDENTIFY and sector write/readback only against the disposable `build/test-disk.img`.
3. Verify E1000 descriptor ownership and TX/RX using QEMU packet capture or a loopback peer.
4. Implement xHCI command/event/transfer rings and enumerate the QEMU USB keyboard.
