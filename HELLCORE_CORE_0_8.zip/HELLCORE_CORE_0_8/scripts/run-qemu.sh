#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
: "${OVMF_CODE:?Set OVMF_CODE to your OVMF_CODE.fd firmware file}"
: "${OVMF_VARS:?Set OVMF_VARS to a writable copy of OVMF_VARS.fd}"
command -v qemu-system-x86_64 >/dev/null 2>&1 || { echo "qemu-system-x86_64 is required" >&2; exit 2; }
[ -d "$ROOT/build/esp" ] || { echo "Run 'make esp' first" >&2; exit 2; }
exec qemu-system-x86_64 \
  -machine q35 -m 2048 \
  -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" \
  -drive if=pflash,format=raw,file="$OVMF_VARS" \
  -drive format=raw,file=fat:rw:"$ROOT/build/esp" \
  -serial stdio -display none -no-reboot
