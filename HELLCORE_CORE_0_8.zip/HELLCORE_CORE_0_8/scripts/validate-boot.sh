#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
make clean all efi esp check
QEMU="${QEMU:-qemu-system-x86_64}"
if ! command -v "$QEMU" >/dev/null 2>&1; then
  echo "BOOT BLOCKED: $QEMU is not installed. Install qemu-system-x86 and ovmf, then rerun."
  exit 2
fi
for p in /usr/share/OVMF/OVMF_CODE.fd /usr/share/ovmf/OVMF_CODE.fd /usr/share/edk2/x64/OVMF_CODE.fd; do
  if [[ -f "$p" ]]; then export OVMF_CODE="$p"; break; fi
done
for p in /usr/share/OVMF/OVMF_VARS.fd /usr/share/ovmf/OVMF_VARS.fd /usr/share/edk2/x64/OVMF_VARS.fd; do
  if [[ -f "$p" ]]; then export OVMF_VARS="$p"; break; fi
done
if [[ ! -f "${OVMF_CODE:-}" || ! -f "${OVMF_VARS:-}" ]]; then
  echo "BOOT BLOCKED: OVMF firmware files not found. Set OVMF_CODE and OVMF_VARS."
  exit 2
fi
mkdir -p build/logs
rm -f build/logs/serial.log
set +e
timeout 35s scripts/run-qemu-uefi.sh
rc=$?
set -e
LOG=build/logs/serial.log
if [[ ! -s "$LOG" ]]; then echo "FAIL: no serial output (qemu exit $rc)"; exit 1; fi
cat "$LOG"
if ! grep -q "HELLCORE CORE 0.8 initialization complete" "$LOG"; then
  echo "FAIL: kernel startup completion marker absent (qemu exit $rc)"; exit 1
fi
for marker in "[OK] Boot information validated" "[OK] 4-level x86-64 paging enabled" "[OK] PCI scan complete" "[AHCI]" "[E1000]" "[xHCI]"; do
  grep -Fq "$marker" "$LOG" || { echo "FAIL: missing serial marker: $marker"; exit 1; }
done
echo "PASS: UEFI boot reached kernel initialization completion; QEMU exit=$rc (timeout is expected for the idle kernel)."
