#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
QEMU="${QEMU:-qemu-system-x86_64}"
OVMF_CODE="${OVMF_CODE:-}"
OVMF_VARS="${OVMF_VARS:-}"
for p in /usr/share/OVMF/OVMF_CODE.fd /usr/share/ovmf/OVMF_CODE.fd /usr/share/edk2/x64/OVMF_CODE.fd; do
  if [[ -z "$OVMF_CODE" && -f "$p" ]]; then OVMF_CODE="$p"; fi
done
for p in /usr/share/OVMF/OVMF_VARS.fd /usr/share/ovmf/OVMF_VARS.fd /usr/share/edk2/x64/OVMF_VARS.fd; do
  if [[ -z "$OVMF_VARS" && -f "$p" ]]; then OVMF_VARS="$p"; fi
done
command -v "$QEMU" >/dev/null || { echo "ERROR: qemu-system-x86_64 not installed" >&2; exit 2; }
[[ -f "$OVMF_CODE" ]] || { echo "ERROR: OVMF_CODE.fd not found; set OVMF_CODE" >&2; exit 2; }
[[ -f "$OVMF_VARS" ]] || { echo "ERROR: OVMF_VARS.fd not found; set OVMF_VARS" >&2; exit 2; }
[[ -f "$ROOT/build/esp/EFI/BOOT/BOOTX64.EFI" && -f "$ROOT/build/esp/EFI/HELLCORE/kernel.elf" ]] || { echo "ERROR: ESP is incomplete; run make esp first" >&2; exit 2; }
mkdir -p "$ROOT/build/logs"
cp "$OVMF_VARS" "$ROOT/build/OVMF_VARS.test.fd"
truncate -s 32M "$ROOT/build/test-disk.img"
"$QEMU" -machine q35,accel=tcg -cpu qemu64 -m 1024 \
  -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" \
  -drive if=pflash,format=raw,file="$ROOT/build/OVMF_VARS.test.fd" \
  -drive format=raw,file=fat:rw:"$ROOT/build/esp" \
  -device ich9-ahci,id=ahci \
  -drive if=none,id=hd0,format=raw,file="$ROOT/build/test-disk.img" \
  -device ide-hd,drive=hd0,bus=ahci.0 \
  -netdev user,id=net0 -device e1000,netdev=net0 \
  -device qemu-xhci,id=xhci -device usb-kbd,bus=xhci.0 \
  -serial file:"$ROOT/build/logs/serial.log" -monitor none -display none -no-reboot -no-shutdown
