#ifndef HELLCORE_ACPI_H
#define HELLCORE_ACPI_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct AcpiMcfgRegion { uint64_t base_address; uint16_t segment; uint8_t start_bus, end_bus; } AcpiMcfgRegion;
typedef struct AcpiInfo { uint8_t revision; char oem_id[7]; uint64_t lapic_address, xsdt_address, rsdt_address; uint32_t processor_count, ioapic_count; uint8_t has_madt, has_mcfg; AcpiMcfgRegion mcfg; } AcpiInfo;
bool acpi_discover(uint64_t rsdp_address, AcpiInfo *out);
#ifdef __cplusplus
}
#endif
#endif
