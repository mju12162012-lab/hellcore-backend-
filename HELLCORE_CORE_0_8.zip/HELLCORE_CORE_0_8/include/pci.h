#ifndef HELLCORE_PCI_H
#define HELLCORE_PCI_H
#include <stdint.h>
#include "acpi.h"
#include "pci_resources.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct PciBar { uint64_t base, size; uint8_t is_io, is_64, prefetchable, assigned; } PciBar;
typedef struct PciDevice { uint8_t bus, device, function, class_code, subclass, prog_if, revision; uint16_t vendor_id, device_id, command, status; PciBar bars[6]; } PciDevice;
typedef struct PciScanStats { uint32_t devices, functions, display, network, storage, usb, audio, other, bars_found, bars_unassigned; uint8_t used_ecam; } PciScanStats;
const char *pci_class_name(uint8_t class_code, uint8_t subclass);
PciScanStats pci_enumerate(const AcpiInfo *acpi, void (*visit)(const PciDevice *));
bool pci_enable_bus_master(const PciDevice *device);
bool pci_assign_unassigned_bars(PciDevice *devices, uint32_t count, PciResourcePool *mmio, PciResourcePool *io, const PciResourceRange *reserved, uint32_t reserved_count, uint32_t *assigned_count);
bool pci_program_bridge_windows(const PciDevice *bridge, PciResourceRange io, PciResourceRange memory, PciResourceRange prefetch);
#ifdef __cplusplus
}
#endif
#endif
