#ifndef HELLCORE_UEFI_LIB_H
#define HELLCORE_UEFI_LIB_H
#include "uefi_services.h"
void hc_uefi_print(EFI_SYSTEM_TABLE *st, const char *ascii);
void hc_memzero(void *dst, UINTN size);
void hc_memcpy(void *dst, const void *src, UINTN size);
#endif
