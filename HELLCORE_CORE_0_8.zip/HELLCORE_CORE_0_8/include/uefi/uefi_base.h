#ifndef HELLCORE_UEFI_BASE_H
#define HELLCORE_UEFI_BASE_H
#include <stdint.h>
#include <stddef.h>

typedef uint8_t  UINT8;
typedef uint16_t UINT16;
typedef int16_t INT16;
typedef uint32_t UINT32;
typedef uint64_t UINT64;
typedef uint64_t UINTN;
typedef uint64_t EFI_STATUS;
typedef uint16_t CHAR16;
typedef void *EFI_HANDLE;
typedef void *EFI_EVENT;
typedef UINT64 EFI_PHYSICAL_ADDRESS;
typedef UINT64 EFI_VIRTUAL_ADDRESS;
typedef UINTN EFI_TPL;
typedef UINT32 EFI_MEMORY_TYPE;
#define EFIAPI
#define EFI_ERROR(s) (((INT64)(s)) < 0)
typedef int64_t INT64;
typedef struct { UINT32 Data1; UINT16 Data2; UINT16 Data3; UINT8 Data4[8]; } EFI_GUID;
typedef struct { UINT16 Year; UINT8 Month, Day, Hour, Minute, Second, Pad1; UINT32 Nanosecond; INT16 TimeZone; UINT8 Daylight, Pad2; } EFI_TIME;
typedef struct { UINT64 Signature; UINT32 Revision; UINT32 HeaderSize; UINT32 CRC32; UINT32 Reserved; } EFI_TABLE_HEADER;
#define EFI_SUCCESS 0
#define EFI_LOAD_ERROR       (0x8000000000000001ULL)
#define EFI_INVALID_PARAMETER (0x8000000000000002ULL)
#define EFI_UNSUPPORTED      (0x8000000000000003ULL)
#define EFI_BUFFER_TOO_SMALL (0x8000000000000005ULL)
#define EFI_OUT_OF_RESOURCES (0x8000000000000009ULL)
#define EFI_NOT_FOUND        (0x800000000000000EULL)
#define EFI_MEMORY_DESCRIPTOR_VERSION 1
#define EFI_PAGE_SIZE 4096ULL
#define EFI_FILE_MODE_READ 0x0000000000000001ULL
#define EfiLoaderData 2
#define AllocateAddress 2

typedef struct {
    UINT32 Type; UINT32 Pad;
    EFI_PHYSICAL_ADDRESS PhysicalStart;
    EFI_VIRTUAL_ADDRESS VirtualStart;
    UINT64 NumberOfPages;
    UINT64 Attribute;
} EFI_MEMORY_DESCRIPTOR;

#endif
