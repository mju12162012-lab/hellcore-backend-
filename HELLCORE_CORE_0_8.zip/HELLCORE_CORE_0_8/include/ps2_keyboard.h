#ifndef HELLCORE_PS2_KEYBOARD_H
#define HELLCORE_PS2_KEYBOARD_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
bool ps2_keyboard_init(void);
bool ps2_keyboard_poll(uint8_t *scancode);
#ifdef __cplusplus
}
#endif
#endif
