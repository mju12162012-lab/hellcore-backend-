#ifndef HELLCORE_VMM_H
#define HELLCORE_VMM_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
bool vmm_init(void);
bool vmm_map_page(uint64_t virtual_address, uint64_t physical_address, uint64_t flags);
bool vmm_unmap_page(uint64_t virtual_address);
bool vmm_mark_mmio_uc(uint64_t physical_address, uint64_t length);
uint64_t vmm_translate(uint64_t virtual_address);
uint64_t vmm_root_address(void);
bool vmm_self_test(void);
#ifdef __cplusplus
}
#endif
#endif
