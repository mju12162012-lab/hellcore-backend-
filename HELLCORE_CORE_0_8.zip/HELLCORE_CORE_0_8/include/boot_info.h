#ifndef HELLCORE_BOOT_INFO_H
#define HELLCORE_BOOT_INFO_H

#include <stdint.h>

#define HELLCORE_BOOT_INFO_MAGIC 0x48434F5245424931ULL /* HCOREBI1 */

/* Kept ABI-simple: the UEFI loader and kernel share this exact structure. */
typedef struct HellcoreBootInfo {
    uint64_t magic;
    uint64_t memory_map_address;
    uint64_t memory_map_size;
    uint64_t memory_descriptor_size;
    uint32_t memory_descriptor_version;
    uint32_t reserved;
    uint64_t acpi_rsdp_address;
} HellcoreBootInfo;

#endif
