#ifndef HELLCORE_PMM_H
#define HELLCORE_PMM_H
#include <stdint.h>
struct HellcoreBootInfo;
struct PmmStats { uint64_t conventional_pages; uint64_t conventional_bytes; uint64_t highest_address; uint64_t allocated_pages; };
#ifdef __cplusplus
extern "C" {
#endif
bool pmm_init(const HellcoreBootInfo *boot);
PmmStats pmm_stats(void);
uint64_t pmm_allocate_frame(void);
bool pmm_free_frame(uint64_t physical_address);
#ifdef __cplusplus
}
#endif
#endif
