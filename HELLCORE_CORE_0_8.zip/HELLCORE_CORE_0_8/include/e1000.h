#ifndef HELLCORE_E1000_H
#define HELLCORE_E1000_H
#include <stdint.h>
#include "pci.h"
typedef struct E1000Stats { uint32_t controllers, initialized, link_up, failures; } E1000Stats;
#ifdef __cplusplus
extern "C" {
#endif
E1000Stats e1000_probe(const PciDevice *devices,uint32_t count);
bool e1000_send(const void *frame,uint16_t length);
int32_t e1000_receive(void *frame,uint16_t capacity);
#ifdef __cplusplus
}
#endif
#endif
