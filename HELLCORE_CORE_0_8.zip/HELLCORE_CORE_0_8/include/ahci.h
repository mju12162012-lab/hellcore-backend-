#ifndef HELLCORE_AHCI_H
#define HELLCORE_AHCI_H
#include <stdint.h>
#include "pci.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct AhciStats { uint32_t controllers, ports, disks, identify_success, failures; } AhciStats;
AhciStats ahci_probe(const PciDevice *devices, uint32_t count);
/* Synchronous one-sector ATA DMA operations. sector_buffer must be 512-byte aligned
   and reside in the kernel's identity-mapped, DMA-addressable memory below 4 GiB. */
bool ahci_read_sector(uint32_t disk_index, uint64_t lba, void *sector_buffer);
bool ahci_write_sector(uint32_t disk_index, uint64_t lba, const void *sector_buffer);
uint32_t ahci_disk_count(void);
#ifdef __cplusplus
}
#endif
#endif
