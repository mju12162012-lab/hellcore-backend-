#ifndef HELLCORE_PCI_RESOURCES_H
#define HELLCORE_PCI_RESOURCES_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct PciResourcePool { uint64_t base, length, cursor; uint32_t allocations; } PciResourcePool;
typedef struct PciResourceRange { uint64_t base, length; } PciResourceRange;
void pci_resource_pool_init(PciResourcePool *pool, uint64_t base, uint64_t length);
bool pci_resource_allocate(PciResourcePool *pool, uint64_t length, uint64_t alignment, const PciResourceRange *reserved, uint32_t reserved_count, uint64_t *out_base);
bool pci_resource_ranges_overlap(PciResourceRange a, PciResourceRange b);
#ifdef __cplusplus
}
#endif
#endif
