#ifndef HELLCORE_ARCH_X86_64_H
#define HELLCORE_ARCH_X86_64_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
void gdt_init(void); void idt_init(void); void gdt_load(const void *descriptor); void idt_load(const void *descriptor); void tss_load(void);
struct InterruptFrame { uint64_t r15,r14,r13,r12,r11,r10,r9,r8,rbp,rdi,rsi,rdx,rcx,rbx,rax,vector,error_code,rip,cs,rflags; };
void interrupt_dispatch(InterruptFrame *frame);
bool apic_init(void); bool apic_timer_start(uint32_t frequency_hz); void apic_eoi(void); uint64_t apic_ticks(void);
#ifdef __cplusplus
}
#endif
#endif
