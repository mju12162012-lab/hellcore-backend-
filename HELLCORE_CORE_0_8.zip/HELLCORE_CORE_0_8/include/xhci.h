#ifndef HELLCORE_XHCI_H
#define HELLCORE_XHCI_H
#include <stdint.h>
#include "pci.h"
typedef struct XhciStats {
    uint32_t controllers, halted, reset, running;
    uint32_t connected_ports, enabled_slots, command_timeouts, failures;
    uint32_t port_reset_failures, enable_slot_failures, address_failures;
    uint32_t addressed_devices, device_descriptors, configuration_descriptors;
    uint32_t evaluated_contexts;
    uint32_t descriptor_failures, enumerated_devices;
} XhciStats;
#ifdef __cplusplus
extern "C" {
#endif
XhciStats xhci_probe(const PciDevice *devices, uint32_t count);
#ifdef __cplusplus
}
#endif
#endif
