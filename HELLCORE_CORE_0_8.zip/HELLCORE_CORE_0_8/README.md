# HELLCORE OS — CORE 0.8

HELLCORE is an independently developed x86-64 operating-system prototype, not a Windows or Linux derivative. This is an incremental freestanding C++20 kernel and native UEFI loader package, **not a complete or hardware-ready operating system**.

## Current subsystem scope

- Native x86-64 UEFI PE32+ loader and ELF64 kernel.
- Four-level bootstrap paging and physical-frame allocator for the first 4 GiB.
- ACPI RSDP/XSDT/MADT/MCFG discovery and PCI enumeration.
- PCI BAR/resource allocator and explicit bridge-window programming APIs.
- GDT, IDT, TSS/IST exception stacks, xAPIC timer prototype.
- AHCI single-sector DMA read/write prototype.
- E1000 descriptor-ring TX/RX prototype.
- xHCI controller/ring setup, port reset, slot enablement, device addressing, and basic USB device/configuration descriptor discovery.
- PS/2 polling keyboard input and COM1 diagnostics.

## Build and host checks

Requirements: Clang/Clang++, LLD, LLD-link, LLVM AR, GNU Make, and a host C++ compiler.

```sh
make clean all efi esp check
nm -u build/kernel.elf
```

## QEMU/OVMF validation

Install QEMU x86-64 and OVMF, then run:

```sh
scripts/validate-boot.sh
```

The script captures serial output in `build/logs/serial.log`. Runtime validation must be completed before claiming successful UEFI boot or hardware-driver operation.

## Important limitations

- Bootstrap identity mapping and current device MMIO/DMA paths are limited to the first 4 GiB.
- No general DMA allocator, IOMMU support, SMP-safe allocator, scheduler, userspace, filesystem, graphics stack, desktop, installer, Secure Boot, or ARM64 port.
- AHCI lacks multi-sector/queued I/O, timeout recovery, and a block layer/filesystem.
- E1000 lacks a network stack, interrupt-driven operation, and robust multi-device/revision handling.
- xHCI lacks complete configuration parsing, SET_CONFIGURATION, hubs, HID, hotplug, and interrupt-driven completion.
- No QEMU/OVMF or physical-hardware success is claimed unless explicitly recorded in the current test report.

See `README_CORE_0_8.md` and `CORE_0_8_TEST_REPORT.md` for details.
