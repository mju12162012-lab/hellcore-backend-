# HELLCORE CORE 0.4 — Build and Test Report

## Scope delivered

CORE 0.4 advances the CORE 0.3 x86-64 freestanding kernel and UEFI loader.

- UEFI loader now passes the firmware ACPI 2.0 RSDP configuration-table pointer to the kernel, falling back to the ACPI 1.0 table when necessary.
- Added ACPI RSDP, RSDT/XSDT and MADT validation with checksums and bounded table lengths.
- MADT discovery reports the local APIC physical address, legacy local-APIC processor entries, x2APIC processor entries and I/O APIC entries; it also parses the local-APIC address override entry.
- ACPI parsing deliberately rejects pointers outside the current 0–4 GiB identity-mapped bootstrap window. Full high-memory mapping is not implemented.
- Added VMM boot-time probes for identity-mapped addresses, a 4 KiB map/translate/unmap path, and physical-frame release after unmapping.
- Kernel serial banner and initialization reporting updated to CORE 0.4.

## Build and checks executed

Command:

```sh
make clean all efi esp check acpi-test
```

Verified:

- Freestanding x86-64 C++20 kernel compiles and links as static ELF64.
- UEFI loader compiles and links as PE32+ EFI application.
- EFI system partition directory layout generated at `build/esp`.
- Existing ELF, PMM and UEFI ABI checks pass.
- New host ACPI parser test passes for valid XSDT/MADT data, processor and I/O APIC entries, and invalid MADT checksum rejection.
- `nm -u build/kernel.elf` reports no undefined kernel symbols.

## Runtime status — not yet verified

- `qemu-system-x86_64` is not installed in the build environment.
- No OVMF/EDK II firmware image was found under `/usr/share`.
- Therefore no QEMU/UEFI boot was performed and no serial boot log exists.
- Page-table activation, VMM boot self-test, ACPI discovery against real firmware tables, APIC MMIO operation, PIT calibration and timer interrupt delivery are compiled but not runtime-verified.
- No physical hardware boot was performed.

## Known limitations

- Bootstrap page tables identity-map only physical 0–4 GiB using 2 MiB pages; ACPI tables above this range are skipped/rejected.
- No general virtual address-space manager, page-table reclamation, SMP-safe PMM locking, x2APIC support, I/O APIC routing, or ACPI interrupt override routing.
- The UEFI SDK remains a minimal project-local interface layer, not a complete or certified UEFI SDK.

## Next verification step

Install QEMU x86-64 and an OVMF firmware package, then run the project's QEMU script with the generated ESP. Capture COM1 output and verify the CORE 0.4 initialization markers before treating any runtime subsystem as validated.
