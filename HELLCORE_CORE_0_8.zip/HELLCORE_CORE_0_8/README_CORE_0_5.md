# HELLCORE CORE 0.5 — Hardware I/O and Boot Validation Progress

CORE 0.5 adds ACPI MCFG/PCIe ECAM discovery, PCI BAR sizing and inventory, conservative uncached mapping for device ranges, and an initial PS/2 keyboard polling driver. COM1 serial output remains the primary diagnostic console. The QEMU profile is configured for q35 with E1000 and AHCI devices to make later PCI enumeration tests representative.

Build and host-side checks:

```sh
make clean all efi esp check
```

UEFI virtual-machine test (requires QEMU and OVMF):

```sh
./scripts/validate-boot.sh
```

Debian prerequisite packages: `sudo apt-get install qemu-system-x86 ovmf`.

Inspect `build/logs/serial.log` after boot. Do not interpret a successful compile as proof of a successful UEFI boot.

**Known boundary:** PCI BARs are probed and existing assigned memory BARs are prepared for MMIO. Unassigned BAR programming is exposed through an explicit resource-manager API, but it is not invoked automatically at boot because a validated host-bridge aperture map is not yet supplied. Bridge windows likewise require caller-supplied trusted ranges. ECAM currently supports segment 0 below 4 GiB. Keyboard input is polling-only. Network packet I/O, general block I/O, and USB enumeration are not yet implemented.


## CORE 0.5.1 hardware bring-up additions

- PCI resource pools provide power-of-two aligned allocation and reserved-range collision rejection. `pci_assign_unassigned_bars` handles I/O, 32-bit memory, and 64-bit memory BAR programming when the caller supplies trusted apertures and reserved ranges. 64-bit BARs can be assigned above 4 GiB; current VMM device mappings and the first AHCI/E1000/xHCI drivers remain limited to MMIO below 4 GiB.
- `pci_program_bridge_windows` programs explicit I/O, non-prefetchable memory, and 64-bit prefetchable windows for type-1 PCI bridges. Resource windows must come from validated firmware/host-bridge apertures. The kernel does not invent apertures or relocate firmware-assigned resources during normal startup.
- AHCI probes ports and issues ATA IDENTIFY using statically allocated, aligned DMA structures below 4 GiB. It is not yet a general block-device driver.
- E1000 performs controller reset and link-state inspection. RX/TX descriptor rings and packet I/O are not implemented.
- xHCI performs controller halt/reset validation. USB slot enable, enumeration, transfer rings, and HID support are not implemented. PS/2 remains the current polling keyboard input path.
- `scripts/validate-boot.sh` rebuilds, runs host checks, then boots QEMU+OVMF with serial logging and checks startup markers.
