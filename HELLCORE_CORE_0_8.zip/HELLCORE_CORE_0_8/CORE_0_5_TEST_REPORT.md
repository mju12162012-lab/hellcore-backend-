# HELLCORE CORE 0.5 — Boot Validation & Hardware I/O Progress

## Implemented in this revision
- Freestanding C++20 x86-64 kernel and native PE32+ UEFI loader.
- ACPI XSDT/RSDT discovery with MADT parsing and PCIe MCFG parsing. MCFG validation checks the ECAM allocation range and supports segment 0 when the complete ECAM window is below 4 GiB.
- PCI configuration access selects PCIe ECAM when a valid supported MCFG region is available and its identity-mapped range can be marked uncached; otherwise it falls back to PCI Configuration Mechanism #1.
- PCI bus/device/function discovery, multifunction detection, class identification, and PCI BAR size/type/base probing. BAR registers are restored after sizing probes. Existing assigned 32-bit MMIO BAR ranges are conservatively marked uncached before device use.
- VMM helper marks 2 MiB identity-map entries covering device MMIO/configuration ranges with PCD/PWT (conservative uncached policy).
- COM1 serial output driver and PS/2 8042 keyboard polling driver. Keyboard initialization enables scanning; the kernel polls and reports raw scancodes over serial.
- QEMU launch script now provides a q35/OVMF test configuration with an E1000 NIC and AHCI disk device for PCI enumeration testing.

## Build and tests run
Command: `make clean all efi esp check`
- PASS — freestanding x86-64 kernel compile and static ELF64 link.
- PASS — native UEFI loader compile and PE32+ EFI application link.
- PASS — ACPI synthetic XSDT/MADT/MCFG test, including PCIe ECAM range and checksum rejection.
- PASS — PCI class-identification host tests.
- PASS — PMM host tests.
- PASS — ELF format/symbol checks.
- PASS — UEFI PE32+ format/subsystem/entry/import/ABI checks.
- PASS — `nm -u build/kernel.elf` produced no undefined symbols.

## Not yet verified / limitations
- QEMU and OVMF are not installed in this environment. `apt-get update` was attempted against Debian repositories but timed out with repeated `Ign` responses; no firmware or VM boot was available. No UEFI boot has been observed and no serial boot log exists.
- No physical hardware boot or driver runtime test has been performed.
- PCI BARs are sized and inventoried; assigned BARs are cache-policy prepared. **Unassigned BARs are not reprogrammed/allocated yet.** Safe BAR assignment requires enumerating PCI bridge windows and reserving a conflict-free aperture from firmware/ACPI host-bridge resources. Blindly assigning a hard-coded MMIO range would be unsafe.
- PCIe ECAM is implemented for segment 0 and ECAM windows fully below 4 GiB because the current bootstrap identity map and PMM cover only 0–4 GiB. High physical ECAM regions and nonzero PCI segments remain unsupported.
- The PS/2 keyboard driver is polling-only, reports raw Set-1/Set-2 controller bytes without translation, and does not yet use IRQ1 or provide a key event queue.
- No functional GPU, NVMe, AHCI command, USB, Ethernet, or audio data-path driver is included yet. E1000 and AHCI are test devices for enumeration only.
- Existing ACPI table parser still requires the RSDP/root/table physical addresses it dereferences to be below 4 GiB.

## Reproduction
Install on Debian/Ubuntu:
`sudo apt-get update && sudo apt-get install -y qemu-system-x86 ovmf`

Then from this project directory:
`make clean all efi esp check`
`./scripts/run-qemu-uefi.sh`

The script writes `build/logs/serial.log`. A successful boot must be verified from the actual serial output, not inferred from compilation.
