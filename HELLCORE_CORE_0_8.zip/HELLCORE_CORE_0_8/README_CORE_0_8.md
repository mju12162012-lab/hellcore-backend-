# HELLCORE OS — CORE 0.8

CORE 0.8 advances the independent x86-64 freestanding C++20 kernel and native UEFI loader. The primary change is an xHCI USB device-discovery path.

## xHCI work in this revision

- Controller halt, reset, CNR wait, and run-state validation.
- DCBAA, command ring, event ring, ERST, and polling event-consumer setup.
- Command-ring cycle handling and command-completion event processing.
- Root-port connection detection and port reset.
- Enable Slot and Address Device command paths.
- Per-slot input/output contexts and EP0 transfer rings.
- Control-IN transfer TRBs for GET_DESCRIPTOR requests.
- Device descriptor and configuration descriptor-header retrieval.
- Evaluate Context update for the EP0 maximum packet size reported by the device descriptor.
- Serial counters for ports, slots, address operations, descriptor requests, and enumeration results.

The discovery path is still an early prototype. It does not parse full configuration/interface/endpoint descriptor trees, issue SET_CONFIGURATION, configure non-default endpoints, support hubs, implement HID keyboard/mouse input, handle hotplug, use interrupt-driven completion, or recover/disable slots after errors.

## Existing hardware work retained

- AHCI single-sector DMA read/write prototype from CORE 0.6.
- E1000 descriptor-ring transmit/receive prototype from CORE 0.6.
- PCI resource allocation and explicit BAR/bridge-window APIs from CORE 0.5.
- ACPI discovery, PMM, VMM, APIC timer, PS/2 polling, and native UEFI loader.

AHCI and E1000 are not runtime-verified and retain their CORE 0.6 limitations. DMA remains restricted to identity-mapped physical memory below 4 GiB; no general DMA allocator or IOMMU support exists.

## Build

```sh
make clean all efi esp check
nm -u build/kernel.elf
```

## QEMU/OVMF boot validation

```sh
scripts/validate-boot.sh
```

The script rebuilds, runs host tests, boots QEMU with OVMF, captures COM1 output in `build/logs/serial.log`, and checks the CORE 0.8 startup marker and driver diagnostics. A successful compile is not evidence of a successful boot or driver operation.

## Current verification status

See `CORE_0_8_TEST_REPORT.md`. This package's kernel and EFI loader build and the existing ACPI, PCI, PMM, ELF, and UEFI ABI checks pass. The QEMU run is blocked when `qemu-system-x86_64` is unavailable. Until a real QEMU/OVMF run is completed, no UEFI boot, AHCI I/O, E1000 packet transfer, or xHCI enumeration success is claimed.
