#include <stdint.h>
#include <stddef.h>
#include "uefi/uefi_file.h"
#include "uefi/hellcore_uefi_lib.h"
#include "boot_info.h"

#define ELFCLASS64 2
#define ELFDATA2LSB 1
#define ET_EXEC 2
#define EM_X86_64 62
#define PT_LOAD 1
#pragma pack(push, 1)
typedef struct { UINT8 ident[16]; UINT16 type, machine; UINT32 version; UINT64 entry, phoff, shoff; UINT32 flags; UINT16 ehsize, phentsize, phnum, shentsize, shnum, shstrndx; } Elf64Ehdr;
typedef struct { UINT32 type, flags; UINT64 offset, vaddr, paddr, filesz, memsz, align; } Elf64Phdr;
#pragma pack(pop)
static void print_error(EFI_SYSTEM_TABLE *st, const char *message) { hc_uefi_print(st, "HELLCORE UEFI: "); hc_uefi_print(st, message); hc_uefi_print(st, "\r\n"); }
static EFI_STATUS read_file(EFI_SYSTEM_TABLE *st, EFI_FILE_PROTOCOL *root, CHAR16 *path, void **buffer, UINTN *size) {
    EFI_FILE_PROTOCOL *file = 0;
    EFI_STATUS status = root->Open(root, &file, path, EFI_FILE_MODE_READ, 0);
    if (EFI_ERROR(status)) return status;
    UINT8 info_buffer[1024];
    UINTN info_size = sizeof(info_buffer);
    status = file->GetInfo(file, &gEfiFileInfoGuid, &info_size, info_buffer);
    if (EFI_ERROR(status)) { file->Close(file); return status; }
    EFI_FILE_INFO *info = (EFI_FILE_INFO*)info_buffer;
    if (!info->FileSize || info->FileSize > 64ULL * 1024ULL * 1024ULL) { file->Close(file); return EFI_LOAD_ERROR; }
    *size = (UINTN)info->FileSize;
    status = st->BootServices->AllocatePool(EfiLoaderData, *size, buffer);
    if (!EFI_ERROR(status)) status = file->Read(file, size, *buffer);
    file->Close(file);
    return status;
}
static EFI_STATUS load_elf64(EFI_SYSTEM_TABLE *st, void *image, UINTN image_size, EFI_PHYSICAL_ADDRESS *entry_out) {
    if (image_size < sizeof(Elf64Ehdr)) return EFI_LOAD_ERROR;
    Elf64Ehdr *eh = (Elf64Ehdr*)image;
    if (eh->ident[0] != 0x7f || eh->ident[1] != 'E' || eh->ident[2] != 'L' || eh->ident[3] != 'F' ||
        eh->ident[4] != ELFCLASS64 || eh->ident[5] != ELFDATA2LSB || eh->type != ET_EXEC ||
        eh->machine != EM_X86_64 || eh->phentsize != sizeof(Elf64Phdr)) return EFI_LOAD_ERROR;
    if (eh->phoff > image_size || (UINT64)eh->phnum * sizeof(Elf64Phdr) > image_size - eh->phoff) return EFI_LOAD_ERROR;
    Elf64Phdr *ph = (Elf64Phdr*)((UINT8*)image + eh->phoff);
    UINT32 loaded = 0;
    for (UINT16 i = 0; i < eh->phnum; ++i) {
        if (ph[i].type != PT_LOAD || !ph[i].memsz) continue;
        if (ph[i].filesz > ph[i].memsz || ph[i].offset > image_size || ph[i].filesz > image_size - ph[i].offset) return EFI_LOAD_ERROR;
        EFI_PHYSICAL_ADDRESS address = ph[i].paddr ? ph[i].paddr : ph[i].vaddr;
        if (!address || (address & (EFI_PAGE_SIZE - 1))) return EFI_LOAD_ERROR;
        UINTN pages = (UINTN)((ph[i].memsz + EFI_PAGE_SIZE - 1) / EFI_PAGE_SIZE);
        EFI_STATUS status = st->BootServices->AllocatePages(AllocateAddress, EfiLoaderData, pages, &address);
        if (EFI_ERROR(status)) return status;
        hc_memzero((void*)(uintptr_t)address, (UINTN)ph[i].memsz);
        hc_memcpy((void*)(uintptr_t)address, (UINT8*)image + ph[i].offset, (UINTN)ph[i].filesz);
        ++loaded;
    }
    if (!loaded) return EFI_LOAD_ERROR;
    *entry_out = eh->entry;
    return EFI_SUCCESS;
}
EFI_STATUS efi_main(EFI_HANDLE image_handle, EFI_SYSTEM_TABLE *st);
/* Keep one absolute image-relative datum so PE/COFF carries a base-relocation table. */
uintptr_t volatile gHellcoreRelocationAnchor = (uintptr_t)&efi_main;
EFI_STATUS efi_main(EFI_HANDLE image_handle, EFI_SYSTEM_TABLE *st) {
    if (!st || !st->BootServices || gHellcoreRelocationAnchor == 0) return EFI_INVALID_PARAMETER;
    print_error(st, "loader 0.5 starting");
    EFI_LOADED_IMAGE_PROTOCOL *loaded = 0;
    EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *fs = 0;
    EFI_FILE_PROTOCOL *root = 0;
    void *kernel_file = 0;
    UINTN kernel_size = 0;
    EFI_STATUS status = st->BootServices->HandleProtocol(image_handle, &gEfiLoadedImageProtocolGuid, (void**)&loaded);
    if (EFI_ERROR(status)) { print_error(st, "loaded-image protocol unavailable"); return status; }
    status = st->BootServices->HandleProtocol(loaded->DeviceHandle, &gEfiSimpleFileSystemProtocolGuid, (void**)&fs);
    if (EFI_ERROR(status)) { print_error(st, "filesystem protocol unavailable"); return status; }
    status = fs->OpenVolume(fs, &root);
    if (EFI_ERROR(status)) { print_error(st, "cannot open EFI volume"); return status; }
    CHAR16 kernel_path[] = {'\\','E','F','I','\\','H','E','L','L','C','O','R','E','\\','k','e','r','n','e','l','.','e','l','f',0};
    status = read_file(st, root, kernel_path, &kernel_file, &kernel_size);
    root->Close(root);
    if (EFI_ERROR(status)) { print_error(st, "cannot read kernel ELF"); return status; }
    EFI_PHYSICAL_ADDRESS entry = 0;
    status = load_elf64(st, kernel_file, kernel_size, &entry);
    st->BootServices->FreePool(kernel_file);
    if (EFI_ERROR(status)) { print_error(st, "kernel ELF rejected or segment allocation failed"); return status; }
    HellcoreBootInfo *boot = 0;
    status = st->BootServices->AllocatePool(EfiLoaderData, sizeof(HellcoreBootInfo), (void**)&boot);
    if (EFI_ERROR(status)) return status;
    UINTN map_size = 0, map_key = 0, descriptor_size = 0;
    UINT32 descriptor_version = 0;
    status = st->BootServices->GetMemoryMap(&map_size, 0, &map_key, &descriptor_size, &descriptor_version);
    if (status != EFI_BUFFER_TOO_SMALL || descriptor_size == 0) return status;
    map_size += descriptor_size * 8;
    void *memory_map = 0;
    status = st->BootServices->AllocatePool(EfiLoaderData, map_size, &memory_map);
    if (EFI_ERROR(status)) return status;
    status = st->BootServices->GetMemoryMap(&map_size, (EFI_MEMORY_DESCRIPTOR*)memory_map, &map_key, &descriptor_size, &descriptor_version);
    if (EFI_ERROR(status)) return status;
    boot->magic = HELLCORE_BOOT_INFO_MAGIC;
    boot->memory_map_address = (UINT64)(uintptr_t)memory_map;
    boot->memory_map_size = map_size;
    boot->memory_descriptor_size = descriptor_size;
    boot->memory_descriptor_version = descriptor_version;
    boot->reserved = 0;
    boot->acpi_rsdp_address = 0;
    /* Prefer the firmware-provided ACPI 2.0 RSDP; retain ACPI 1.0 as fallback. */
    typedef struct { UINT8 VendorGuid[16]; void *VendorTable; } HcConfigurationTable;
    HcConfigurationTable *configuration = (HcConfigurationTable*)st->ConfigurationTable;
    for (UINTN i = 0; i < st->NumberOfTableEntries; ++i) {
        const UINT8 *guid = configuration[i].VendorGuid;
        const UINT8 acpi20[16] = {0x71,0xE8,0x68,0x88,0xF1,0xE4,0xD3,0x11,0xBC,0x22,0x00,0x80,0xC7,0x3C,0x88,0x81};
        const UINT8 acpi10[16] = {0x30,0x2D,0x9D,0xEB,0x88,0x2D,0xD3,0x11,0x9A,0x16,0x00,0x90,0x27,0x3F,0xC1,0x4D};
        UINTN j = 0; while (j < 16 && guid[j] == acpi20[j]) ++j;
        if (j == 16) { boot->acpi_rsdp_address = (UINT64)(uintptr_t)configuration[i].VendorTable; break; }
        j = 0; while (j < 16 && guid[j] == acpi10[j]) ++j;
        if (j == 16) boot->acpi_rsdp_address = (UINT64)(uintptr_t)configuration[i].VendorTable;
    }
    status = st->BootServices->ExitBootServices(image_handle, map_key);
    if (EFI_ERROR(status)) return status;
    typedef void (__attribute__((sysv_abi)) *KernelEntry)(HellcoreBootInfo*);
    ((KernelEntry)(uintptr_t)entry)(boot);
    for (;;) __asm__ __volatile__("hlt");
}
