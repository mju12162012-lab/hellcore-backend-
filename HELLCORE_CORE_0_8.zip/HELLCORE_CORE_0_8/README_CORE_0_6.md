# HELLCORE OS — CORE 0.6

## Scope
CORE 0.6 advances the x86-64 freestanding C++20 kernel and native UEFI loader toward runtime-tested hardware I/O. It retains the CORE 0.5 boot architecture and adds a first synchronous AHCI sector I/O API and an E1000 descriptor-ring data path.

## Changes in this revision

- Fixed AHCI command-slot selection: each discovered port now receives its own command-list, received-FIS, command-table and IDENTIFY DMA slot.
- AHCI IDENTIFY parses the 48-bit sector count, with 28-bit capacity fallback.
- Added synchronous one-sector ATA DMA read (`READ DMA EXT`, 0x25) and write (`WRITE DMA EXT`, 0x35) APIs. The caller buffer must be 512-byte aligned, identity-mapped, physically contiguous and below 4 GiB. Requests are bounds-checked against IDENTIFY capacity.
- Added PCI bus-master enable and readback verification; AHCI, E1000 and xHCI probe paths request bus mastering before DMA/controller operation.
- Added E1000 32-entry TX/RX descriptor rings, per-descriptor DMA buffers, controller reset, ring programming, transmit and receive APIs.
- Updated kernel banner and boot-validation marker to CORE 0.6.

## Build and host checks

Run:

```sh
make clean all efi esp check
nm -u build/kernel.elf
```

The build and existing host checks pass in the current environment. The kernel has no unresolved symbols.

## Runtime validation status

**NOT RUNTIME-VERIFIED.** This environment still lacks `qemu-system-x86_64` and OVMF. `apt-get update` timed out while attempting to obtain packages. No firmware boot was executed and no real serial boot log exists. Therefore this release does not claim a successful UEFI boot or successful AHCI/E1000/xHCI runtime initialization.

The existing `scripts/validate-boot.sh` requires QEMU and both OVMF firmware files. Once available, run it to capture `build/logs/serial.log` and verify the CORE 0.6 boot sequence.

## Driver maturity / known limitations

- AHCI is a synchronous one-sector DMA prototype. No multi-sector batching, NCQ, interrupt-driven completion, timeout recovery/reset, hotplug, DMA allocator, block layer or filesystem is present. Caller buffers must satisfy the documented DMA constraints.
- E1000 now has basic descriptor-ring TX/RX APIs. It has not been run against QEMU or a physical NIC. Interrupts, robust reset/error recovery, multiple hardware revisions, checksum/offload features and network stack integration are not implemented. Only the first compatible controller is operational in this implementation.
- xHCI remains controller halt/reset only. Slot/context setup, command/event/transfer rings, USB device enumeration, control transfers and HID are still outstanding.
- PCI BAR assignment/bridge-window APIs still require validated host-bridge apertures; the kernel does not automatically relocate firmware-assigned BARs.
- DMA and MMIO paths are currently constrained to addresses below 4 GiB. General IOMMU support and high-memory DMA mapping are absent.

## Next validation gates

1. Install QEMU x86-64 and OVMF, boot with the supplied q35 profile, and archive the full serial log.
2. Verify AHCI IDENTIFY and perform read/write/readback against the disposable `build/test-disk.img` only.
3. Run E1000 TX/RX loopback or host-side packet capture tests and verify descriptor ownership transitions.
4. Implement xHCI command/event/transfer rings and enumerate the attached QEMU USB keyboard before claiming USB support.
