#include <stdint.h>
#include "boot_info.h"
#include "arch_x86_64.h"
#include "pmm.h"
#include "vmm.h"
#include "acpi.h"
#include "pci.h"
#include "ps2_keyboard.h"
#include "ahci.h"
#include "e1000.h"
#include "xhci.h"

static inline void outb(uint16_t port, uint8_t value) { __asm__ __volatile__("outb %0, %1" : : "a"(value), "Nd"(port)); }
static inline uint8_t inb(uint16_t port) { uint8_t value; __asm__ __volatile__("inb %1, %0" : "=a"(value) : "Nd"(port)); return value; }
static void serial_init() {
    outb(0x3F9, 0x00); outb(0x3FB, 0x80); outb(0x3F8, 0x01); outb(0x3F9, 0x00);
    outb(0x3FB, 0x03); outb(0x3FA, 0xC7); outb(0x3FC, 0x0B);
}
static void serial_putc(char c) {
    for (uint32_t spin = 0; spin < 1000000; ++spin) if (inb(0x3FD) & 0x20) break;
    outb(0x3F8, static_cast<uint8_t>(c));
}
static void serial_write(const char *s) { while (*s) serial_putc(*s++); }
static void serial_hex(uint64_t value) {
    static const char digits[] = "0123456789ABCDEF";
    serial_write("0x");
    bool started = false;
    for (int shift = 60; shift >= 0; shift -= 4) {
        const uint8_t nibble = static_cast<uint8_t>((value >> shift) & 0xF);
        if (nibble || started || shift == 0) { serial_putc(digits[nibble]); started = true; }
    }
}
[[noreturn]] static void halt_forever() { for (;;) __asm__ __volatile__("cli; hlt"); }

extern "C" void kernel_exception_report(uint64_t vector, uint64_t error, uint64_t rip) {
    serial_write("\r\n[HELLCORE PANIC] CPU exception vector="); serial_hex(vector);
    serial_write(" error="); serial_hex(error); serial_write(" rip="); serial_hex(rip);
    serial_write("\r\nSystem halted.\r\n");
    halt_forever();
}

static PciDevice pci_devices[256];
static uint32_t pci_device_count = 0;
static void pci_log_device(const PciDevice *d) {
    if (pci_device_count < 256) { auto *dst = reinterpret_cast<uint8_t *>(&pci_devices[pci_device_count++]); const auto *src = reinterpret_cast<const uint8_t *>(d); for (unsigned j=0;j<sizeof(PciDevice);++j) dst[j]=src[j]; }
    serial_write("[PCI] "); serial_hex(d->bus); serial_write(":"); serial_hex(d->device); serial_write("."); serial_hex(d->function);
    serial_write(" vendor="); serial_hex(d->vendor_id); serial_write(" device="); serial_hex(d->device_id);
    serial_write(" class="); serial_write(pci_class_name(d->class_code,d->subclass));
    for (unsigned i=0;i<6;++i) if(d->bars[i].size) { serial_write(" BAR"); serial_hex(i); serial_write(" base="); serial_hex(d->bars[i].base); serial_write(" size="); serial_hex(d->bars[i].size); }
    serial_write("\r\n");
}

extern "C" [[noreturn]] void kernel_main(HellcoreBootInfo *boot) {
    serial_init();
    serial_write("\r\n========================================\r\n HELLCORE OS - CORE 0.8\r\n========================================\r\n");
    if (!boot || boot->magic != HELLCORE_BOOT_INFO_MAGIC) {
        serial_write("[FATAL] Invalid boot information.\r\n"); halt_forever();
    }
    serial_write("[OK] Boot information validated\r\n");
    const uint64_t acpi_rsdp_address = boot->acpi_rsdp_address;
    if (!pmm_init(boot)) { serial_write("[FATAL] Physical memory map unavailable or invalid\r\n"); halt_forever(); }
    PmmStats stats = pmm_stats();
    serial_write("[OK] Physical frame allocator online; free pages: "); serial_hex(stats.conventional_pages); serial_write("\r\n");
    serial_write("[OK] Physical address ceiling managed: "); serial_hex(stats.highest_address); serial_write("\r\n");
    if (!vmm_init()) { serial_write("[FATAL] Page-table construction failed\r\n"); halt_forever(); }
    serial_write("[OK] 4-level x86-64 paging enabled; 0-4 GiB identity mapped\r\n");
    if (!vmm_self_test()) { serial_write("[FATAL] Virtual-memory translation/map self-test failed\r\n"); halt_forever(); }
    serial_write("[OK] VMM identity probes, 4 KiB mapping and translation verified\r\n");
    AcpiInfo acpi{};
    if (acpi_discover(acpi_rsdp_address, &acpi)) {
        serial_write("[OK] ACPI RSDP validated; revision: "); serial_hex(acpi.revision);
        serial_write(" OEM: "); serial_write(acpi.oem_id); serial_write("\r\n");
        if (acpi.has_madt) {
            serial_write("[OK] MADT found; LAPIC address: "); serial_hex(acpi.lapic_address);
            serial_write(" CPUs: "); serial_hex(acpi.processor_count);
            serial_write(" IOAPICs: "); serial_hex(acpi.ioapic_count); serial_write("\r\n");
        } else serial_write("[WARN] ACPI MADT not present\r\n");
        if (acpi.has_mcfg) { serial_write("[OK] PCIe MCFG found; ECAM base="); serial_hex(acpi.mcfg.base_address); serial_write(" buses="); serial_hex(acpi.mcfg.start_bus); serial_write("-"); serial_hex(acpi.mcfg.end_bus); serial_write("\r\n"); }
    } else serial_write("[WARN] ACPI RSDP unavailable or invalid; ACPI discovery skipped\r\n");
    serial_write("[INFO] PCI configuration-space discovery starting (mechanism 1)\r\n");
    pci_device_count = 0;
    const PciScanStats pci = pci_enumerate(&acpi,pci_log_device);
    serial_write("[OK] PCI scan complete; functions: "); serial_hex(pci.functions);
    serial_write(" display: "); serial_hex(pci.display); serial_write(" network: "); serial_hex(pci.network);
    serial_write(" storage: "); serial_hex(pci.storage); serial_write(" USB: "); serial_hex(pci.usb);
    serial_write(" audio: "); serial_hex(pci.audio); serial_write(" BARs: "); serial_hex(pci.bars_found);
    serial_write(" unassigned BARs: "); serial_hex(pci.bars_unassigned);
    serial_write(pci.used_ecam ? " via PCIe ECAM\r\n" : " via PCI config mechanism 1\r\n");
    const AhciStats ahci = ahci_probe(pci_devices, pci_device_count);
    serial_write("[AHCI] controllers="); serial_hex(ahci.controllers); serial_write(" ports="); serial_hex(ahci.ports); serial_write(" IDENTIFY-success="); serial_hex(ahci.identify_success); serial_write(" failures="); serial_hex(ahci.failures); serial_write("\r\n");
    const E1000Stats net = e1000_probe(pci_devices, pci_device_count);
    serial_write("[E1000] controllers="); serial_hex(net.controllers); serial_write(" initialized="); serial_hex(net.initialized); serial_write(" link-up="); serial_hex(net.link_up); serial_write(" failures="); serial_hex(net.failures); serial_write("\r\n");
    const XhciStats usb = xhci_probe(pci_devices, pci_device_count);
    serial_write("[xHCI] controllers="); serial_hex(usb.controllers); serial_write(" halted="); serial_hex(usb.halted); serial_write(" reset="); serial_hex(usb.reset); serial_write(" running="); serial_hex(usb.running); serial_write(" connected-ports="); serial_hex(usb.connected_ports); serial_write(" slots="); serial_hex(usb.enabled_slots); serial_write(" addressed="); serial_hex(usb.addressed_devices); serial_write(" device-descriptors="); serial_hex(usb.device_descriptors); serial_write(" config-descriptors="); serial_hex(usb.configuration_descriptors); serial_write(" evaluated-contexts="); serial_hex(usb.evaluated_contexts); serial_write(" enumerated="); serial_hex(usb.enumerated_devices); serial_write(" port-reset-failures="); serial_hex(usb.port_reset_failures); serial_write(" address-failures="); serial_hex(usb.address_failures); serial_write(" descriptor-failures="); serial_hex(usb.descriptor_failures); serial_write(" failures="); serial_hex(usb.failures); serial_write("\r\n");
    if (ps2_keyboard_init()) serial_write("[OK] PS/2 keyboard controller initialized; polling input driver active\r\n");
    else serial_write("[WARN] PS/2 keyboard controller unavailable\r\n");
    gdt_init();
    serial_write("[OK] GDT + 64-bit TSS installed; dedicated DF/NMI/MC stacks active\r\n");
    idt_init();
    serial_write("[OK] IDT installed; exception gates use IST stacks; LAPIC timer vector ready\r\n");
    outb(0x21, 0xFF); outb(0xA1, 0xFF);
    if (apic_init()) {
        serial_write("[OK] Local APIC enabled; calibrating periodic timer against PIT\r\n");
        if (!apic_timer_start(100)) { serial_write("[WARN] LAPIC timer calibration failed\r\n"); halt_forever(); }
        serial_write("[OK] LAPIC periodic timer calibrated to 100 Hz\r\n");
        __asm__ __volatile__("sti");
        __asm__ __volatile__("1: pause; loop 1b" : : "c"(50000000ULL) : "memory");
        __asm__ __volatile__("cli");
        serial_write("[OK] LAPIC timer interrupts observed: "); serial_hex(apic_ticks()); serial_write("\r\n");
    } else serial_write("[WARN] CPU local APIC unavailable; timer left disabled\r\n");
    uint8_t key = 0;
    if (ps2_keyboard_poll(&key)) { serial_write("[INPUT] PS/2 scancode="); serial_hex(key); serial_write("\r\n"); }
    serial_write("[OK] Physical frame release API compiled; allocator metadata active\r\n");
    serial_write("\r\nHELLCORE CORE 0.8 initialization complete.\r\n");
    __asm__ __volatile__("sti");
    for (;;) {
        uint8_t scancode = 0;
        if (ps2_keyboard_poll(&scancode)) { serial_write("[INPUT] PS/2 scancode="); serial_hex(scancode); serial_write("\r\n"); }
        __asm__ __volatile__("pause");
    }
}
extern "C" [[noreturn]] void _start(HellcoreBootInfo *boot) { kernel_main(boot); }
