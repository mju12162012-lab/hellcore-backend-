#include <stdint.h>
#include "pmm.h"
#include "vmm.h"
namespace {
constexpr uint64_t P=1, W=2, PS=0x80, ADDRESS=0x000FFFFFFFFFF000ULL;
uint64_t *root=nullptr;
uint64_t alloc_table() { uint64_t p=pmm_allocate_frame(); if(!p) return 0; auto *t=reinterpret_cast<uint64_t*>(p); for(unsigned i=0;i<512;++i)t[i]=0; return p; }
}
extern "C" bool vmm_init(void) {
    uint64_t pml4=alloc_table(), pdpt=alloc_table(); if(!pml4||!pdpt)return false;
    root=reinterpret_cast<uint64_t*>(pml4); root[0]=pdpt|P|W;
    for(uint64_t g=0;g<4;++g) {
        uint64_t pd=alloc_table(); if(!pd)return false;
        reinterpret_cast<uint64_t*>(pdpt)[g]=pd|P|W;
        auto *entries=reinterpret_cast<uint64_t*>(pd);
        for(uint64_t i=0;i<512;++i) { uint64_t phys=(g*512+i)*0x200000ULL; entries[i]=phys|P|W|PS; if(phys==0xFEC00000ULL || phys==0xFEE00000ULL) entries[i]|=0x18ULL; }
    }
    uint64_t cr3=pml4, cr0; __asm__ __volatile__("mov %0, %%cr3"::"r"(cr3):"memory");
    __asm__ __volatile__("mov %%cr0, %0":"=r"(cr0)); cr0|=(1ULL<<31)|(1ULL<<16);
    __asm__ __volatile__("mov %0, %%cr0"::"r"(cr0):"memory"); return true;
}
extern "C" bool vmm_map_page(uint64_t va,uint64_t pa,uint64_t flags) {
    if(!root || (va&0xfff)||(pa&0xfff))return false;
    uint64_t idx[4]={(va>>39)&511,(va>>30)&511,(va>>21)&511,(va>>12)&511};
    uint64_t *table=root;
    for(unsigned level=0;level<3;++level) {
        uint64_t e=table[idx[level]];
        if(!(e&P)) { uint64_t n=alloc_table(); if(!n)return false; table[idx[level]]=n|P|W; e=n|P|W; }
        else if((e&PS) && level==2) {
            uint64_t n=alloc_table(); if(!n)return false;
            uint64_t base=e&0x000FFFFFFFE00000ULL;
            uint64_t inherited=e&(P|W|0x4|0x8|0x10|0x20|0x40|0x100|0x200|(1ULL<<63));
            auto *pt=reinterpret_cast<uint64_t*>(n);
            for(uint64_t j=0;j<512;++j) pt[j]=(base+j*0x1000ULL)|inherited;
            table[idx[level]]=n|P|W; e=n|P|W;
        } else if(e&PS) return false;
        table=reinterpret_cast<uint64_t*>(e&ADDRESS);
    }
    table[idx[3]]=(pa&ADDRESS)|P|(flags&(W|0x4|0x8|0x10|0x100|0x200|(1ULL<<63))); __asm__ __volatile__("invlpg (%0)"::"r"(va):"memory"); return true;
}
extern "C" bool vmm_unmap_page(uint64_t va) {
    if (!root || (va & 0xFFF)) return false;
    const uint64_t idx[4] = {(va >> 39) & 511, (va >> 30) & 511, (va >> 21) & 511, (va >> 12) & 511};
    uint64_t *table = root;
    for (unsigned level = 0; level < 3; ++level) {
        const uint64_t entry = table[idx[level]];
        if (!(entry & P) || (entry & PS)) return false;
        table = reinterpret_cast<uint64_t *>(entry & ADDRESS);
    }
    if (!(table[idx[3]] & P)) return false;
    table[idx[3]] = 0;
    __asm__ __volatile__("invlpg (%0)" :: "r"(va) : "memory");
    return true;
}

extern "C" bool vmm_mark_mmio_uc(uint64_t base,uint64_t length) {
    if(!root || !length || base>=0x100000000ULL || length>0x100000000ULL-base) return false;
    const uint64_t first=base&~0x1FFFFFULL;
    const uint64_t end=(base+length+0x1FFFFFULL)&~0x1FFFFFULL;
    if(end>0x100000000ULL) return false;
    auto *pdpt=reinterpret_cast<uint64_t*>(root[0]&ADDRESS);
    for(uint64_t p=first;p<end;p+=0x200000ULL) {
        const uint64_t gi=p>>30, pi=(p>>21)&511;
        if(gi>=4 || !(pdpt[gi]&P)) return false;
        auto *pd=reinterpret_cast<uint64_t*>(pdpt[gi]&ADDRESS);
        if(!(pd[pi]&P) || !(pd[pi]&PS)) return false;
        pd[pi]|=0x18ULL; // PCD | PWT: conservative UC mapping for device registers/config space
        __asm__ __volatile__("invlpg (%0)"::"r"(p):"memory");
    }
    return true;
}

extern "C" uint64_t vmm_translate(uint64_t va) {
    if(!root)return 0; uint64_t *t=root; uint64_t ix[4]={(va>>39)&511,(va>>30)&511,(va>>21)&511,(va>>12)&511};
    for(unsigned l=0;l<4;++l){uint64_t e=t[ix[l]];if(!(e&P))return 0;if(l==1&&(e&PS))return (e&0x000FFFFFC0000000ULL)|(va&0x3FFFFFFFULL);if(l==2&&(e&PS))return (e&0x000FFFFFFFE00000ULL)|(va&0x1FFFFFULL);if(l==3)return(e&ADDRESS)|(va&0xfff);t=reinterpret_cast<uint64_t*>(e&ADDRESS);}return 0;
}
extern "C" uint64_t vmm_root_address(void){return reinterpret_cast<uint64_t>(root);}

extern "C" bool vmm_self_test(void) {
    if (!root) return false;
    const uint64_t probes[] = {0x1000ULL,0x1FFFFFULL,0x200000ULL,0x3FFFFFFFULL,0x40000000ULL,0xFEE00000ULL};
    for (uint64_t va : probes) if (vmm_translate(va) != va) return false;
    uint64_t frame=pmm_allocate_frame(); if(!frame)return false;
    constexpr uint64_t test_va=0xFFFF900000000000ULL;
    bool mapped=vmm_map_page(test_va,frame,0x2);
    bool translated=mapped&&vmm_translate(test_va+0x5A5)==frame+0x5A5;
    bool unmapped=mapped&&vmm_unmap_page(test_va)&&vmm_translate(test_va)==0;
    bool released=unmapped&&pmm_free_frame(frame); return translated&&unmapped&&released;
}
