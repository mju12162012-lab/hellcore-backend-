#include "pci_resources.h"
namespace {
bool add_overflow(uint64_t a,uint64_t b,uint64_t *out){*out=a+b;return *out<a;}
bool align_up(uint64_t v,uint64_t a,uint64_t *out){if(!a||(a&(a-1)))return false;uint64_t t;if(add_overflow(v,a-1,&t))return false;*out=t&~(a-1);return true;}
}
extern "C" void pci_resource_pool_init(PciResourcePool *p,uint64_t b,uint64_t n){if(!p)return;p->base=b;p->length=n;p->cursor=b;p->allocations=0;}
extern "C" bool pci_resource_ranges_overlap(PciResourceRange a,PciResourceRange b){uint64_t ae,be;if(!a.length||!b.length||add_overflow(a.base,a.length,&ae)||add_overflow(b.base,b.length,&be))return true;return a.base<be&&b.base<ae;}
extern "C" bool pci_resource_allocate(PciResourcePool *p,uint64_t n,uint64_t align,const PciResourceRange *r,uint32_t count,uint64_t *out){
 if(!p||!out||!n||!align||(align&(align-1)))return false;
 uint64_t end;if(add_overflow(p->base,p->length,&end))return false;
 uint64_t candidate;if(!align_up(p->cursor,align,&candidate))return false;
 for(uint32_t pass=0;pass<=count;++pass){uint64_t candidate_end;if(add_overflow(candidate,n,&candidate_end)||candidate_end>end)return false;bool moved=false;
  for(uint32_t i=0;i<count;++i){if(!r||!r[i].length)continue;PciResourceRange c{candidate,n};if(pci_resource_ranges_overlap(c,r[i])){uint64_t re;if(add_overflow(r[i].base,r[i].length,&re)||!align_up(re,align,&candidate))return false;moved=true;break;}}
  if(!moved){*out=candidate;p->cursor=candidate_end;++p->allocations;return true;}
 }
 return false;
}
