#include <stdint.h>
#include "boot_info.h"
#include "pmm.h"
namespace {
constexpr uint32_t EFI_CONVENTIONAL_MEMORY = 7;
constexpr uint64_t PAGE_SIZE = 4096;
constexpr uint64_t MAX_FRAMES = 1ULL << 20; // allocator metadata covers physical 0..4 GiB
constexpr uint64_t BITMAP_WORDS = MAX_FRAMES / 64;
struct __attribute__((packed)) EfiMemoryDescriptor { uint32_t type, padding; uint64_t physical_start, virtual_start, number_of_pages, attribute; };
alignas(16) uint64_t bitmap[BITMAP_WORDS]; // 1 = unavailable, 0 = free
alignas(16) uint64_t allocated[BITMAP_WORDS]; // distinguishes releasable allocations from reserved frames
PmmStats stats{};
uint64_t cursor = 256; // keep first MiB unavailable
const uint8_t *map_bytes = nullptr;
uint64_t map_size = 0, descriptor_size = 0;
inline bool used(uint64_t n) { return (bitmap[n >> 6] & (1ULL << (n & 63))) != 0; }
inline void mark(uint64_t n) { bitmap[n >> 6] |= 1ULL << (n & 63); }
inline void clear(uint64_t n) { bitmap[n >> 6] &= ~(1ULL << (n & 63)); }
}
extern "C" bool pmm_init(const HellcoreBootInfo *boot) {
    for (uint64_t i=0;i<BITMAP_WORDS;++i) { bitmap[i]=~0ULL; allocated[i]=0; }
    stats={}; cursor=256; map_bytes=nullptr; map_size=descriptor_size=0;
    if (!boot || boot->magic != HELLCORE_BOOT_INFO_MAGIC || !boot->memory_map_address ||
        boot->memory_descriptor_size < sizeof(EfiMemoryDescriptor) || boot->memory_map_size < boot->memory_descriptor_size) return false;
    map_bytes=reinterpret_cast<const uint8_t*>(boot->memory_map_address); map_size=boot->memory_map_size; descriptor_size=boot->memory_descriptor_size;
    for(uint64_t off=0; off+sizeof(EfiMemoryDescriptor)<=map_size; off+=descriptor_size) {
        const auto *d=reinterpret_cast<const EfiMemoryDescriptor*>(map_bytes+off);
        if(d->type!=EFI_CONVENTIONAL_MEMORY || d->physical_start>=MAX_FRAMES*PAGE_SIZE) continue;
        uint64_t start=(d->physical_start+PAGE_SIZE-1)/PAGE_SIZE; if(start<256) start=256;
        uint64_t end=d->physical_start/PAGE_SIZE+d->number_of_pages;
        if(end>MAX_FRAMES) end=MAX_FRAMES;
        if(end<=start) continue;
        for(uint64_t f=start;f<end;++f) clear(f);
        const uint64_t pages=end-start;
        stats.conventional_pages+=pages; stats.conventional_bytes+=pages*PAGE_SIZE;
        if(end*PAGE_SIZE>stats.highest_address) stats.highest_address=end*PAGE_SIZE;
    }
    for(uint64_t f=0;f<256;++f) mark(f);
    return stats.conventional_pages!=0;
}
extern "C" PmmStats pmm_stats(void) { return stats; }
extern "C" uint64_t pmm_allocate_frame(void) {
    if(!map_bytes) return 0;
    for(uint64_t scanned=0;scanned<MAX_FRAMES-256;++scanned) {
        uint64_t f=cursor++; if(cursor>=MAX_FRAMES) cursor=256;
        if(!used(f)) { mark(f); allocated[f>>6] |= 1ULL << (f&63); --stats.conventional_pages; stats.conventional_bytes-=PAGE_SIZE; ++stats.allocated_pages; return f*PAGE_SIZE; }
    }
    return 0;
}
extern "C" bool pmm_free_frame(uint64_t address) {
    if((address&(PAGE_SIZE-1)) || address<PAGE_SIZE*256 || address>=MAX_FRAMES*PAGE_SIZE) return false;
    uint64_t f=address/PAGE_SIZE; if(!used(f) || !(allocated[f>>6] & (1ULL << (f&63)))) return false;
    allocated[f>>6] &= ~(1ULL << (f&63)); clear(f); ++stats.conventional_pages; stats.conventional_bytes+=PAGE_SIZE; if(stats.allocated_pages) --stats.allocated_pages; if(f<cursor) cursor=f; return true;
}
