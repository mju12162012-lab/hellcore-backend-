#include "pci.h"
#include "vmm.h"
namespace {
static AcpiMcfgRegion ecam{};
static bool ecam_active = false;
static inline void out32(uint16_t p, uint32_t v) { __asm__ __volatile__("outl %0, %1" : : "a"(v), "Nd"(p)); }
static inline uint32_t in32(uint16_t p) { uint32_t v; __asm__ __volatile__("inl %1, %0" : "=a"(v) : "Nd"(p)); return v; }
uint32_t cfg_read(uint8_t b, uint8_t d, uint8_t f, uint16_t off) {
    if (ecam_active && b >= ecam.start_bus && b <= ecam.end_bus && off < 4096) {
        const uint64_t a = ecam.base_address + (uint64_t(b - ecam.start_bus) << 20) + (uint64_t(d) << 15) + (uint64_t(f) << 12) + off;
        return *reinterpret_cast<volatile uint32_t *>(static_cast<uintptr_t>(a));
    }
    if (off >= 256) return 0xFFFFFFFFu;
    const uint32_t address = 0x80000000u | (uint32_t(b) << 16) | (uint32_t(d) << 11) | (uint32_t(f) << 8) | (off & 0xFCu);
    out32(0xCF8, address); return in32(0xCFC);
}
void cfg_write(uint8_t b, uint8_t d, uint8_t f, uint16_t off, uint32_t value) {
    if (ecam_active && b >= ecam.start_bus && b <= ecam.end_bus && off < 4096) {
        const uint64_t a = ecam.base_address + (uint64_t(b - ecam.start_bus) << 20) + (uint64_t(d) << 15) + (uint64_t(f) << 12) + off;
        *reinterpret_cast<volatile uint32_t *>(static_cast<uintptr_t>(a)) = value; return;
    }
    if (off >= 256) return;
    const uint32_t address = 0x80000000u | (uint32_t(b) << 16) | (uint32_t(d) << 11) | (uint32_t(f) << 8) | (off & 0xFCu);
    out32(0xCF8, address); out32(0xCFC, value);
}
void probe_bars(PciDevice *o) {
    const uint8_t header_type = uint8_t(cfg_read(o->bus,o->device,o->function,0x0C) >> 16) & 0x7Fu;
    const uint8_t bar_count = header_type == 1 ? 2 : (header_type == 0 ? 6 : 0);
    const uint16_t command = o->command;
    cfg_write(o->bus,o->device,o->function,4,uint32_t(command & ~3u));
    for (uint8_t i=0; i<bar_count; ++i) {
        const uint16_t off = uint16_t(0x10 + i*4);
        const uint32_t original = cfg_read(o->bus,o->device,o->function,off);
        if (original == 0xFFFFFFFFu) break;
        const bool io = (original & 1u) != 0;
        const bool is64 = !io && ((original >> 1) & 3u) == 2u && i < 5;
        const uint32_t original_hi = is64 ? cfg_read(o->bus,o->device,o->function,off+4) : 0;
        cfg_write(o->bus,o->device,o->function,off,0xFFFFFFFFu);
        if (is64) cfg_write(o->bus,o->device,o->function,off+4,0xFFFFFFFFu);
        const uint32_t mask_lo = cfg_read(o->bus,o->device,o->function,off);
        const uint32_t mask_hi = is64 ? cfg_read(o->bus,o->device,o->function,off+4) : 0;
        cfg_write(o->bus,o->device,o->function,off,original);
        if (is64) cfg_write(o->bus,o->device,o->function,off+4,original_hi);
        uint64_t mask = io ? uint64_t(mask_lo & ~3u) : uint64_t(mask_lo & ~0xFu);
        if (is64) mask |= uint64_t(mask_hi) << 32;
        const uint64_t size = is64 ? (~mask + 1ULL) : (io ? uint64_t(uint32_t(~uint32_t(mask)) + 1u) : uint64_t(uint32_t(~uint32_t(mask)) + 1u));
        if (!mask || !size || (size & (size-1))) { if (is64) ++i; continue; }
        PciBar &bar=o->bars[i]; bar.base = io ? (original & ~3u) : (is64 ? ((uint64_t(original_hi)<<32)|(original&~0xFULL)) : (original&~0xFULL));
        bar.size=size; bar.is_io=io; bar.is_64=is64; bar.prefetchable=!io && ((original&8u)!=0); bar.assigned=bar.base!=0;
        if (is64) { o->bars[i+1].size=0; ++i; }
    }
    cfg_write(o->bus,o->device,o->function,4,command);
}
void read_function(uint8_t b,uint8_t d,uint8_t f,PciDevice *o) {
    const uint32_t id=cfg_read(b,d,f,0), cls=cfg_read(b,d,f,8), cmd=cfg_read(b,d,f,4);
    o->bus=b; o->device=d; o->function=f; o->vendor_id=uint16_t(id); o->device_id=uint16_t(id>>16);
    o->command=uint16_t(cmd); o->status=uint16_t(cmd>>16); o->revision=uint8_t(cls); o->prog_if=uint8_t(cls>>8); o->subclass=uint8_t(cls>>16); o->class_code=uint8_t(cls>>24);
    probe_bars(o);
}
}
extern "C" const char *pci_class_name(uint8_t c,uint8_t s) {
    switch(c) { case 0x01:return "mass-storage"; case 0x02:return "network"; case 0x03:return "display"; case 0x04:return "multimedia-audio"; case 0x06:return s==4?"pci-bridge":"bridge"; case 0x0C:return s==3?"usb-controller":"serial-bus"; case 0x0D:return "wireless-controller"; default:return "other"; }
}
extern "C" PciScanStats pci_enumerate(const AcpiInfo *a,void (*visit)(const PciDevice *)) {
    PciScanStats st{}; ecam_active=false;
    if(a && a->has_mcfg && a->mcfg.segment==0 && a->mcfg.base_address<0x100000000ULL) {
        const uint64_t bytes=(uint64_t(a->mcfg.end_bus)-a->mcfg.start_bus+1ULL)<<20;
        if(vmm_mark_mmio_uc(a->mcfg.base_address,bytes)) { ecam=a->mcfg; ecam_active=true; st.used_ecam=1; }
    }
    const uint32_t first=ecam_active?ecam.start_bus:0, last=ecam_active?ecam.end_bus:255;
    for(uint32_t b=first;b<=last;++b) for(uint8_t d=0;d<32;++d) {
        const uint32_t h=cfg_read(uint8_t(b),d,0,0); if(uint16_t(h)==0xFFFFu) continue;
        const uint8_t header=uint8_t(cfg_read(uint8_t(b),d,0,0x0C)>>16), count=(header&0x80u)?8:1;
        for(uint8_t f=0;f<count;++f) { if(uint16_t(cfg_read(uint8_t(b),d,f,0))==0xFFFFu) continue;
            PciDevice dev{}; read_function(uint8_t(b),d,f,&dev); ++st.functions; ++st.devices;
            switch(dev.class_code) { case 3:++st.display;break; case 2:++st.network;break; case 1:++st.storage;break; case 4:++st.audio;break; case 0x0C:if(dev.subclass==3)++st.usb;else ++st.other;break; default:++st.other;break; }
            for(const auto &bar:dev.bars) if(bar.size) { ++st.bars_found; if(!bar.assigned) ++st.bars_unassigned; else if(!bar.is_io && bar.base<0x100000000ULL && bar.size<=0x100000000ULL-bar.base) (void)vmm_mark_mmio_uc(bar.base,bar.size); }
            if(visit) visit(&dev);
        }
    }
    return st;
}

extern "C" bool pci_assign_unassigned_bars(PciDevice *ds, uint32_t count,
        PciResourcePool *mmio, PciResourcePool *io,
        const PciResourceRange *reserved, uint32_t reserved_count,
        uint32_t *assigned_count) {
    if (!ds || !mmio || !io || !assigned_count) return false;
    *assigned_count = 0;
    static PciResourceRange mmio_used[2048];
    static PciResourceRange io_used[2048];
    uint32_t mmio_used_count = 0, io_used_count = 0;
    if (reserved_count > 512) return false;
    for (uint32_t r = 0; r < reserved_count; ++r) {
        if (reserved && reserved[r].length) {
            mmio_used[mmio_used_count++] = reserved[r];
            io_used[io_used_count++] = reserved[r];
        }
    }
    for (uint32_t n = 0; n < count; ++n) {
        for (uint32_t b = 0; b < 6; ++b) {
            const PciBar &bar = ds[n].bars[b];
            if (!bar.assigned || !bar.size) continue;
            PciResourceRange range{bar.base, bar.size};
            PciResourceRange *list = bar.is_io ? io_used : mmio_used;
            uint32_t &used = bar.is_io ? io_used_count : mmio_used_count;
            if (used >= 2048) return false;
            for (uint32_t x = 0; x < used; ++x) if (pci_resource_ranges_overlap(range,list[x])) return false;
            list[used++] = range;
        }
    }
    for (uint32_t n = 0; n < count; ++n) {
        PciDevice &d = ds[n];
        const uint8_t header = uint8_t(cfg_read(d.bus,d.device,d.function,0x0C) >> 16) & 0x7Fu;
        const uint8_t maxbars = header == 1 ? 2 : (header == 0 ? 6 : 0);
        const uint16_t oldcmd = uint16_t(cfg_read(d.bus,d.device,d.function,4));
        for (uint8_t i = 0; i < maxbars; ++i) {
            PciBar &bar = d.bars[i];
            if (!bar.size || bar.assigned) continue;
            PciResourcePool *pool = bar.is_io ? io : mmio;
            const uint64_t minimum = bar.is_io ? 4ULL : 16ULL;
            const uint64_t alignment = bar.size < minimum ? minimum : bar.size;
            uint64_t base = 0;
            PciResourceRange *used_ranges = bar.is_io ? io_used : mmio_used;
            uint32_t used_count = bar.is_io ? io_used_count : mmio_used_count;
            if (!pci_resource_allocate(pool,bar.size,alignment,used_ranges,used_count,&base)) return false;
            if ((bar.is_io && base > 0xFFFFULL) ||
                (!bar.is_io && !bar.is_64 && (base > 0xFFFFFFFFULL || bar.size > 0x100000000ULL-base))) return false;
            if (bar.is_64 && i + 1 >= maxbars) return false;
            cfg_write(d.bus,d.device,d.function,4,uint32_t(oldcmd & ~3u));
            const uint16_t off = uint16_t(0x10 + i*4);
            const uint32_t low = uint32_t(base) | (bar.is_io ? 1u : ((bar.prefetchable ? 8u : 0u) | (bar.is_64 ? 4u : 0u)));
            if (bar.is_64) cfg_write(d.bus,d.device,d.function,off+4,uint32_t(base >> 32));
            cfg_write(d.bus,d.device,d.function,off,low);
            cfg_write(d.bus,d.device,d.function,4,uint32_t(oldcmd | (bar.is_io ? 1u : 2u)));
            bar.base = base;
            bar.assigned = 1;
            if (bar.is_io) { if (io_used_count >= 2048) return false; io_used[io_used_count++] = {base,bar.size}; }
            else { if (mmio_used_count >= 2048) return false; mmio_used[mmio_used_count++] = {base,bar.size}; }
            ++*assigned_count;
            if (bar.is_64) ++i;
        }
    }
    return true;
}

extern "C" bool pci_program_bridge_windows(const PciDevice *d,
        PciResourceRange io, PciResourceRange mem, PciResourceRange pre) {
    if (!d || d->class_code != 0x06 || d->subclass != 0x04) return false;
    const uint8_t header = uint8_t(cfg_read(d->bus,d->device,d->function,0x0C) >> 16) & 0x7Fu;
    if (header != 1) return false;
    auto valid = [](PciResourceRange r, uint64_t align, uint64_t limit) {
        uint64_t end = r.base + r.length;
        return r.length && !(r.base & (align-1)) && !(r.length & (align-1)) && end >= r.base && end <= limit;
    };
    if (io.length && !valid(io,0x1000,0x10000ULL)) return false;
    if (mem.length && !valid(mem,0x100000,0x100000000ULL)) return false;
    if (pre.length && !valid(pre,0x100000,~0ULL)) return false;
    if (mem.length && pre.length && pci_resource_ranges_overlap(mem,pre)) return false;
    const uint32_t original_command = cfg_read(d->bus,d->device,d->function,4);
    cfg_write(d->bus,d->device,d->function,4,original_command & ~3u);
    if (mem.length) {
        const uint64_t last = mem.base + mem.length - 1;
        cfg_write(d->bus,d->device,d->function,0x20,
            uint32_t((mem.base >> 16) & 0xFFF0u) | uint32_t(last & 0xFFF00000u));
    }
    if (pre.length) {
        const uint64_t last = pre.base + pre.length - 1;
        const uint32_t low = uint32_t((pre.base >> 16) & 0xFFF0u) |
            uint32_t(last & 0xFFF00000u) | 0x00010001u;
        cfg_write(d->bus,d->device,d->function,0x24,low);
        cfg_write(d->bus,d->device,d->function,0x28,uint32_t(pre.base >> 32));
        cfg_write(d->bus,d->device,d->function,0x2C,uint32_t(last >> 32));
    }
    if (io.length) {
        const uint64_t last = io.base + io.length - 1;
        const uint32_t low = uint32_t((io.base >> 8) & 0xF0u) |
            uint32_t((last >> 8) & 0xF000u) | 0x00000101u;
        cfg_write(d->bus,d->device,d->function,0x1C,low);
        cfg_write(d->bus,d->device,d->function,0x30,
            uint32_t(io.base >> 16) | uint32_t(last & 0xFFFF0000u));
    }
    uint32_t command = original_command & ~3u;
    if (io.length) command |= 1u;
    if (mem.length || pre.length) command |= 2u;
    cfg_write(d->bus,d->device,d->function,4,command);
    return true;
}

extern "C" bool pci_enable_bus_master(const PciDevice *d) {
    if (!d) return false;
    const uint32_t value = cfg_read(d->bus,d->device,d->function,4);
    cfg_write(d->bus,d->device,d->function,4,value | (1u<<2));
    return (cfg_read(d->bus,d->device,d->function,4) & (1u<<2)) != 0;
}
