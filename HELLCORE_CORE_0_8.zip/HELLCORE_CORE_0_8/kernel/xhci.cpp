#include "xhci.h"
#include "vmm.h"
#include <stddef.h>

namespace {
constexpr uint32_t kRingCount = 256;
constexpr uint32_t kRingUsable = kRingCount - 1;
constexpr uint32_t kWaitLimit = 5000000;
constexpr uint32_t kMaxSlots = 32;
constexpr uint32_t kMaxPorts = 64;
constexpr uint32_t kContextBytes = 64;

struct alignas(16) Trb { uint64_t parameter; uint32_t status; uint32_t control; };
struct alignas(64) ErstEntry { uint64_t ring_base; uint32_t ring_size; uint32_t reserved; };
struct alignas(64) Erst { ErstEntry entries[1]; };
struct alignas(64) TrbRing { Trb trbs[kRingCount]; };
struct alignas(64) ContextBlock { uint8_t bytes[33 * kContextBytes]; };
struct alignas(64) DeviceContext { uint8_t bytes[32 * kContextBytes]; };

static uint64_t dcbaa[256] __attribute__((aligned(64))) {};
static TrbRing command_ring __attribute__((aligned(64))) {};
static TrbRing event_ring __attribute__((aligned(64))) {};
static TrbRing ep0_rings[kMaxSlots + 1] __attribute__((aligned(64))) {};
static ContextBlock input_contexts[kMaxSlots + 1] __attribute__((aligned(64))) {};
static DeviceContext output_contexts[kMaxSlots + 1] __attribute__((aligned(64))) {};
static Erst erst __attribute__((aligned(64))) {};
static uint8_t descriptor_buffer[256] __attribute__((aligned(64))) {};
static uint32_t command_enqueue = 0;
static uint32_t event_dequeue = 0;
static uint32_t ep0_enqueue[kMaxSlots + 1] {};
static uint8_t command_cycle = 1;
static uint8_t event_cycle = 1;
static uint8_t ep0_cycle[kMaxSlots + 1] {};
static uint32_t context_stride = 32;
static volatile uint64_t *event_dequeue_ptr = nullptr;
static volatile uint32_t *doorbells = nullptr;

static inline uint32_t rd32(volatile uint32_t *p) { return *p; }
static inline void wr32(volatile uint32_t *p, uint32_t v) { *p = v; }
static inline void wr64(volatile uint64_t *p, uint64_t v) { p[0] = v; }
static bool wait_mask(volatile uint32_t *p, uint32_t mask, bool set) {
    for (uint32_t i = 0; i < kWaitLimit; ++i) {
        if (((rd32(p) & mask) != 0) == set) return true;
        __asm__ __volatile__("pause");
    }
    return false;
}
static bool dma32(const void *p, uint64_t bytes) {
    const uint64_t a = reinterpret_cast<uintptr_t>(p);
    return a < 0x100000000ULL && bytes <= 0x100000000ULL - a;
}
static void zero_bytes(void *p, size_t n) {
    auto *b = static_cast<uint8_t *>(p);
    for (size_t i = 0; i < n; ++i) b[i] = 0;
}
static void copy_bytes(void *dst, const void *src, size_t n) {
    auto *d = static_cast<uint8_t *>(dst);
    const auto *s = static_cast<const uint8_t *>(src);
    for (size_t i = 0; i < n; ++i) d[i] = s[i];
}
static void ring_push(TrbRing *ring, uint32_t *enqueue, uint8_t *cycle,
                      uint64_t parameter, uint32_t status, uint32_t control) {
    if (*enqueue >= kRingUsable) {
        Trb &link = ring->trbs[kRingUsable];
        link.parameter = reinterpret_cast<uintptr_t>(&ring->trbs[0]);
        link.status = 0;
        link.control = (6u << 10) | (1u << 1) | *cycle;
        __asm__ __volatile__("sfence" ::: "memory");
        *enqueue = 0;
        *cycle ^= 1u;
    }
    Trb &t = ring->trbs[*enqueue];
    t.parameter = parameter;
    t.status = status;
    t.control = (control & ~1u) | *cycle;
    __asm__ __volatile__("sfence" ::: "memory");
    ++(*enqueue);
}
static bool next_event(Trb *out) {
    for (uint32_t i = 0; i < kWaitLimit; ++i) {
        Trb &e = event_ring.trbs[event_dequeue];
        __asm__ __volatile__("lfence" ::: "memory");
        if ((e.control & 1u) == event_cycle) {
            *out = e;
            ++event_dequeue;
            if (event_dequeue == kRingCount) { event_dequeue = 0; event_cycle ^= 1u; }
            wr64(event_dequeue_ptr, reinterpret_cast<uintptr_t>(&event_ring.trbs[event_dequeue]) | (1u << 3));
            return true;
        }
        __asm__ __volatile__("pause");
    }
    return false;
}
static bool command(uint64_t parameter, uint32_t status, uint32_t control,
                    uint8_t *completion, uint8_t *slot_id) {
    ring_push(&command_ring, &command_enqueue, &command_cycle, parameter, status, control);
    wr32(doorbells, 0);
    for (uint32_t i = 0; i < kWaitLimit; ++i) {
        Trb e{};
        if (!next_event(&e)) return false;
        const uint32_t type = (e.control >> 10) & 0x3Fu;
        if (type != 33u) continue;
        *completion = static_cast<uint8_t>(e.status >> 24);
        *slot_id = static_cast<uint8_t>(e.control >> 24);
        return true;
    }
    return false;
}
static bool control_in(uint8_t slot, uint8_t *buffer, uint16_t length,
                       uint8_t request_type, uint8_t request,
                       uint16_t value, uint16_t index) {
    if (!slot || slot > kMaxSlots || !dma32(buffer, length)) return false;
    TrbRing &ring = ep0_rings[slot];
    uint32_t &enqueue = ep0_enqueue[slot];
    uint8_t &cycle = ep0_cycle[slot];
    const uint64_t setup = static_cast<uint64_t>(request_type) |
        (static_cast<uint64_t>(request) << 8) |
        (static_cast<uint64_t>(value) << 16) |
        (static_cast<uint64_t>(index) << 32) |
        (static_cast<uint64_t>(length) << 48);
    // Setup Stage: immediate 8-byte setup packet, with an IN data stage.
    ring_push(&ring, &enqueue, &cycle, setup, 8u | (3u << 16),
              (2u << 10) | (1u << 6) | (1u << 4));
    ring_push(&ring, &enqueue, &cycle, reinterpret_cast<uintptr_t>(buffer),
              length, (3u << 10) | (1u << 16) | (1u << 4));
    ring_push(&ring, &enqueue, &cycle, 0, 0, (4u << 10) | (1u << 5));
    wr32(doorbells + slot, 1u); // slot doorbell, endpoint target 1 (EP0)
    for (uint32_t i = 0; i < kWaitLimit; ++i) {
        Trb e{};
        if (!next_event(&e)) return false;
        const uint32_t type = (e.control >> 10) & 0x3Fu;
        if (type != 32u) continue;
        const uint8_t event_slot = static_cast<uint8_t>(e.control >> 24);
        const uint8_t endpoint = static_cast<uint8_t>((e.control >> 16) & 0x1Fu);
        if (event_slot != slot || endpoint != 1u) continue;
        return static_cast<uint8_t>(e.status >> 24) == 1u;
    }
    return false;
}
static uint32_t *context_at(uint8_t *base, uint32_t index) {
    return reinterpret_cast<uint32_t *>(base + static_cast<size_t>(index) * context_stride);
}
static bool address_device(uint8_t slot, uint8_t port, uint8_t speed) {
    if (!slot || slot > kMaxSlots) return false;
    ContextBlock &input = input_contexts[slot];
    DeviceContext &output = output_contexts[slot];
    TrbRing &ep0 = ep0_rings[slot];
    zero_bytes(&input, sizeof(input));
    zero_bytes(&output, sizeof(output));
    zero_bytes(&ep0, sizeof(ep0));
    ep0_enqueue[slot] = 0;
    ep0_cycle[slot] = 1;
    ep0.trbs[kRingUsable].parameter = reinterpret_cast<uintptr_t>(&ep0.trbs[0]);
    ep0.trbs[kRingUsable].control = (6u << 10) | (1u << 1) | 1u;
    dcbaa[slot] = reinterpret_cast<uintptr_t>(&output);

    uint32_t *control_ctx = context_at(input.bytes, 0);
    control_ctx[1] = (1u << 0) | (1u << 1); // Add Slot and EP0 contexts.
    uint32_t *slot_ctx = context_at(input.bytes, 1);
    slot_ctx[0] = (static_cast<uint32_t>(speed) << 20) | (1u << 27);
    slot_ctx[1] = static_cast<uint32_t>(port) << 16;
    uint32_t *ep_ctx = context_at(input.bytes, 2);
    const uint32_t max_packet = speed >= 4 ? 512u : (speed == 3 ? 64u : 8u);
    ep_ctx[2] = (3u << 1) | (4u << 3) | (max_packet << 16);
    ep_ctx[3] = reinterpret_cast<uintptr_t>(&ep0.trbs[0]) | 1u;
    ep_ctx[4] = 8u;

    uint8_t completion = 0, result_slot = 0;
    if (!command(reinterpret_cast<uintptr_t>(&input), 0, (11u << 10) | (static_cast<uint32_t>(slot) << 24), &completion, &result_slot)) return false;
    return completion == 1u && result_slot == slot;
}
static bool reset_port(volatile uint32_t *portsc) {
    uint32_t value = rd32(portsc);
    if (!(value & 1u)) return false;
    const uint32_t clear_changes = value & 0x00FE0000u;
    wr32(portsc, (value & (1u << 9)) | (1u << 4) | clear_changes);
    for (uint32_t i = 0; i < kWaitLimit; ++i) {
        value = rd32(portsc);
        if (!(value & (1u << 4)) && (value & (1u << 1))) return true;
        __asm__ __volatile__("pause");
    }
    return false;
}
static bool enumerate_port(uint8_t port, volatile uint32_t *portsc, XhciStats *stats) {
    if (!reset_port(portsc)) { ++stats->port_reset_failures; return false; }
    const uint32_t ps = rd32(portsc);
    const uint8_t speed = static_cast<uint8_t>((ps >> 10) & 0xFu);
    uint8_t completion = 0, slot = 0;
    if (!command(0, 0, (9u << 10), &completion, &slot) || completion != 1u || !slot || slot > kMaxSlots) {
        ++stats->enable_slot_failures;
        return false;
    }
    ++stats->enabled_slots;
    if (!address_device(slot, port, speed)) { ++stats->address_failures; return false; }
    ++stats->addressed_devices;
    zero_bytes(descriptor_buffer, sizeof(descriptor_buffer));
    if (!control_in(slot, descriptor_buffer, 18, 0x80, 6, 0x0100, 0)) {
        ++stats->descriptor_failures;
        return false;
    }
    if (descriptor_buffer[0] < 18 || descriptor_buffer[1] != 1) {
        ++stats->descriptor_failures;
        return false;
    }
    ++stats->device_descriptors;
    // Full-speed control endpoints may advertise a packet size other than 8.
    // Apply the descriptor's bMaxPacketSize0 through Evaluate Context before
    // issuing the next control transfer.
    const uint32_t descriptor_mps = speed >= 4 ? 512u : descriptor_buffer[7];
    if (descriptor_mps != 8u && descriptor_mps != 16u && descriptor_mps != 32u &&
        descriptor_mps != 64u && descriptor_mps != 512u) {
        ++stats->descriptor_failures;
        return false;
    }
    ContextBlock &input = input_contexts[slot];
    DeviceContext &output = output_contexts[slot];
    zero_bytes(&input, sizeof(input));
    uint32_t *input_control = context_at(input.bytes, 0);
    input_control[1] = 1u << 1; // Add EP0 context only.
    uint32_t *input_ep0 = context_at(input.bytes, 2);
    const uint32_t *output_ep0 = context_at(output.bytes, 1);
    copy_bytes(input_ep0, output_ep0, context_stride);
    input_ep0[2] = (input_ep0[2] & 0x0000FFFFu) | (descriptor_mps << 16);
    uint8_t eval_completion = 0, eval_slot = 0;
    if (!command(reinterpret_cast<uintptr_t>(&input), 0,
                 (13u << 10) | (static_cast<uint32_t>(slot) << 24),
                 &eval_completion, &eval_slot) || eval_completion != 1u || eval_slot != slot) {
        ++stats->address_failures;
        return false;
    }
    ++stats->evaluated_contexts;
    // Fetch the configuration descriptor header. This confirms EP0 control transfers
    // beyond the initial device descriptor; configuration/interface activation follows.
    zero_bytes(descriptor_buffer, sizeof(descriptor_buffer));
    if (!control_in(slot, descriptor_buffer, 9, 0x80, 6, 0x0200, 0) ||
        descriptor_buffer[0] < 9 || descriptor_buffer[1] != 2) {
        ++stats->descriptor_failures;
        return false;
    }
    ++stats->configuration_descriptors;
    return true;
}
static bool init_controller(uint64_t base, uint64_t size, XhciStats *s) {
    if (base >= 0x100000000ULL || size < 0x1000 || !vmm_mark_mmio_uc(base, size)) return false;
    volatile uint8_t *mmio = reinterpret_cast<volatile uint8_t *>(static_cast<uintptr_t>(base));
    const uint8_t caplen = mmio[0];
    if (caplen < 0x20) return false;
    volatile uint32_t *cap = reinterpret_cast<volatile uint32_t *>(static_cast<uintptr_t>(base));
    const uint32_t hcs1 = rd32(cap + 1);
    const uint32_t hcc1 = rd32(reinterpret_cast<volatile uint32_t *>(static_cast<uintptr_t>(base + 0x10)));
    const uint32_t max_slots = hcs1 & 0xFFu;
    const uint32_t max_ports = (hcs1 >> 24) & 0xFFu;
    const uint32_t dboff = rd32(cap + 5) & ~3u;
    const uint32_t rtsoff = rd32(cap + 6) & ~0x1Fu;
    if (!max_slots || !max_ports || dboff >= size || rtsoff + 0x40 >= size) return false;
    const uint32_t slots = max_slots < kMaxSlots ? max_slots : kMaxSlots;
    const uint32_t ports = max_ports < kMaxPorts ? max_ports : kMaxPorts;
    if (static_cast<uint64_t>(dboff) + (static_cast<uint64_t>(slots) + 1u) * 4u > size ||
        static_cast<uint64_t>(caplen) + 0x400u + static_cast<uint64_t>(ports) * 0x10u > size ||
        static_cast<uint64_t>(caplen) + 0x3Cu > size) return false;
    context_stride = (hcc1 & (1u << 2)) ? 64u : 32u;

    volatile uint32_t *op = reinterpret_cast<volatile uint32_t *>(static_cast<uintptr_t>(base + caplen));
    volatile uint32_t *usbcmd = op;
    volatile uint32_t *usbsts = op + 1;
    wr32(usbcmd, rd32(usbcmd) & ~1u);
    if (!wait_mask(usbsts, 1u, true)) return false;
    ++s->halted;
    wr32(usbcmd, rd32(usbcmd) | (1u << 1));
    if (!wait_mask(usbcmd, 1u << 1, false) || !wait_mask(usbsts, 1u << 11, false)) return false;
    ++s->reset;

    if (!dma32(dcbaa, sizeof(dcbaa)) || !dma32(&command_ring, sizeof(command_ring)) ||
        !dma32(&event_ring, sizeof(event_ring)) || !dma32(&erst, sizeof(erst)) ||
        !dma32(input_contexts, sizeof(input_contexts)) || !dma32(output_contexts, sizeof(output_contexts)) ||
        !dma32(ep0_rings, sizeof(ep0_rings)) || !dma32(descriptor_buffer, sizeof(descriptor_buffer))) return false;
    zero_bytes(dcbaa, sizeof(dcbaa));
    zero_bytes(&command_ring, sizeof(command_ring));
    zero_bytes(&event_ring, sizeof(event_ring));
    zero_bytes(&erst, sizeof(erst));
    command_enqueue = 0; event_dequeue = 0; command_cycle = 1; event_cycle = 1;
    command_ring.trbs[kRingUsable].parameter = reinterpret_cast<uintptr_t>(&command_ring.trbs[0]);
    command_ring.trbs[kRingUsable].control = (6u << 10) | (1u << 1) | 1u;
    erst.entries[0].ring_base = reinterpret_cast<uintptr_t>(&event_ring.trbs[0]);
    erst.entries[0].ring_size = kRingCount;

    volatile uint64_t *dcbaap = reinterpret_cast<volatile uint64_t *>(static_cast<uintptr_t>(base + caplen + 0x30));
    volatile uint64_t *crcr = reinterpret_cast<volatile uint64_t *>(static_cast<uintptr_t>(base + caplen + 0x18));
    volatile uint32_t *config = reinterpret_cast<volatile uint32_t *>(static_cast<uintptr_t>(base + caplen + 0x38));
    wr64(dcbaap, reinterpret_cast<uintptr_t>(dcbaa));
    wr64(crcr, reinterpret_cast<uintptr_t>(&command_ring.trbs[0]) | 1u);
    wr32(config, slots);

    volatile uint32_t *runtime = reinterpret_cast<volatile uint32_t *>(static_cast<uintptr_t>(base + rtsoff));
    volatile uint32_t *iman = runtime + 0x20 / 4;
    volatile uint32_t *erstsz = runtime + 0x28 / 4;
    volatile uint64_t *erstba = reinterpret_cast<volatile uint64_t *>(static_cast<uintptr_t>(base + rtsoff + 0x30));
    event_dequeue_ptr = reinterpret_cast<volatile uint64_t *>(static_cast<uintptr_t>(base + rtsoff + 0x38));
    wr32(iman, 0); wr32(erstsz, 1);
    wr64(erstba, reinterpret_cast<uintptr_t>(&erst.entries[0]));
    wr64(event_dequeue_ptr, reinterpret_cast<uintptr_t>(&event_ring.trbs[0]) | (1u << 3));
    doorbells = reinterpret_cast<volatile uint32_t *>(static_cast<uintptr_t>(base + dboff));

    wr32(usbcmd, rd32(usbcmd) | 1u);
    if (!wait_mask(usbsts, 1u, false)) return false;
    ++s->running;

    volatile uint32_t *portsc = reinterpret_cast<volatile uint32_t *>(static_cast<uintptr_t>(base + caplen + 0x400));
    for (uint32_t p = 0; p < ports; ++p) {
        const uint32_t value = rd32(portsc + p * 4);
        if (!(value & 1u)) continue;
        ++s->connected_ports;
        if (enumerate_port(static_cast<uint8_t>(p + 1), portsc + p * 4, s)) ++s->enumerated_devices;
    }
    return true;
}
}

extern "C" XhciStats xhci_probe(const PciDevice *devices, uint32_t count) {
    XhciStats s{};
    for (uint32_t i = 0; i < count; ++i) {
        const PciDevice &d = devices[i];
        if (d.class_code != 0x0C || d.subclass != 3 || d.prog_if != 0x30) continue;
        ++s.controllers;
        const PciBar *bar = nullptr;
        for (unsigned b = 0; b < 6; ++b)
            if (d.bars[b].size && !d.bars[b].is_io && d.bars[b].assigned) { bar = &d.bars[b]; break; }
        if (!bar || !pci_enable_bus_master(&d) || !init_controller(bar->base, bar->size, &s)) ++s.failures;
    }
    return s;
}
