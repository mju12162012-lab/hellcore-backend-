#include "ahci.h"
#include "vmm.h"

namespace {
struct HbaPort { volatile uint32_t clb,clbu,fb,fbu,is,ie,cmd,res0,tfd,sig,ssts,sctl,serr,sact,ci,sntf,fbs,devslp,res1[10]; };
struct Hba { volatile uint32_t cap,ghc,is,pi,vs,ccc_ctl,ccc_pts,em_loc,em_ctl,cap2,bohc; uint8_t reserved[0x74]; uint8_t vendor[0x60]; HbaPort ports[32]; };
struct alignas(1024) CommandList { uint8_t bytes[1024]; };
struct alignas(256) ReceivedFis { uint8_t bytes[256]; };
struct alignas(128) CommandTable { uint8_t bytes[256]; };
struct alignas(512) DmaSector { uint8_t bytes[512]; };
struct Disk { HbaPort *port; uint64_t sectors; bool valid; };
static CommandList command_lists[32];
static ReceivedFis received_fis[32];
static CommandTable command_tables[32];
static DmaSector identify_data[32];
static Disk disks[32];
static uint32_t disk_count;
static inline void pause_cpu(){__asm__ __volatile__("pause");}
static bool wait_clear(volatile uint32_t *r,uint32_t mask){for(uint32_t i=0;i<5000000;++i){if(!(*r&mask))return true;pause_cpu();}return false;}
static bool issue(HbaPort *p,uint32_t slot,uint8_t command,uint64_t lba,uint16_t sectors,void *buffer){
 if(slot>=32||!buffer||!sectors||sectors!=1)return false;
 const uintptr_t cl_addr=reinterpret_cast<uintptr_t>(&command_lists[slot]);
 const uintptr_t ct_addr=reinterpret_cast<uintptr_t>(&command_tables[slot]);
 const uintptr_t data_addr=reinterpret_cast<uintptr_t>(buffer);
 if((cl_addr>>32)||(ct_addr>>32)||(data_addr>>32)||(data_addr&1u))return false;
 if(!wait_clear(&p->tfd,0x88u))return false;
 auto *cl=reinterpret_cast<uint32_t*>(&command_lists[slot]);
 for(unsigned i=0;i<256;++i)cl[i]=0;
 auto *fis=reinterpret_cast<uint8_t*>(&command_tables[slot]);
 for(unsigned i=0;i<64;++i)fis[i]=0;
 cl[0]=5u|(1u<<16); cl[2]=uint32_t(ct_addr); cl[3]=0;
 fis[0]=0x27; fis[1]=0x80; fis[2]=command;
 fis[4]=uint8_t(lba); fis[5]=uint8_t(lba>>8); fis[6]=uint8_t(lba>>16); fis[7]=0x40;
 fis[8]=uint8_t(lba>>24); fis[9]=uint8_t(lba>>32); fis[10]=uint8_t(lba>>40);
 fis[12]=uint8_t(sectors); fis[13]=uint8_t(sectors>>8);
 uint32_t *prdt=reinterpret_cast<uint32_t*>(fis+128);
 prdt[0]=uint32_t(data_addr); prdt[1]=0; prdt[2]=0; prdt[3]=uint32_t(uint32_t(sectors)*512u-1u)|(1u<<31);
 p->is=0xFFFFFFFFu; p->ci=1u<<slot;
 for(uint32_t i=0;i<10000000;++i){
  const uint32_t is=p->is;
  if(is&(1u<<30))return false;
  if(!(p->ci&(1u<<slot)))return !(p->tfd&1u)&&!(is&(1u<<0));
  pause_cpu();
 }
 return false;
}
static bool identify(HbaPort *p,uint32_t slot,DmaSector *data,uint64_t *sector_count){
 if(!issue(p,slot,0xEC,0,1,data))return false;
 const uint16_t *w=reinterpret_cast<const uint16_t*>(data->bytes);
 uint64_t n=(uint64_t(w[100])|(uint64_t(w[101])<<16)|(uint64_t(w[102])<<32)|(uint64_t(w[103])<<48));
 if(!n)n=uint64_t(w[60])|(uint64_t(w[61])<<16);
 *sector_count=n; return n!=0;
}
}
extern "C" AhciStats ahci_probe(const PciDevice *devs,uint32_t count){
 AhciStats s{}; disk_count=0;
 for(uint32_t i=0;i<count;++i){
  const PciDevice &d=devs[i]; if(d.class_code!=1||d.subclass!=6||d.prog_if!=1)continue; ++s.controllers;
  const PciBar &bar=d.bars[5];
  if(bar.is_io||!bar.assigned||bar.base>=0x100000000ULL||bar.size<0x1100||!pci_enable_bus_master(&d)||!vmm_mark_mmio_uc(bar.base,bar.size)){++s.failures;continue;}
  auto *h=reinterpret_cast<Hba*>(uintptr_t(bar.base)); h->ghc|=1u<<31;
  for(uint32_t p=0;p<32;++p){
   if(!(h->pi&(1u<<p)))continue; ++s.ports; HbaPort *port=&h->ports[p]; const uint32_t ssts=port->ssts;
   if((ssts&0x0Fu)!=3u||((ssts>>8)&0x0Fu)!=1u)continue;
   const uint32_t slot=disk_count; if(slot>=32)break;
   port->cmd&=~1u; if(!wait_clear(&port->cmd,1u<<15)){++s.failures;continue;}
   port->cmd&=~(1u<<4); if(!wait_clear(&port->cmd,1u<<14)){++s.failures;continue;}
   const uintptr_t cl=reinterpret_cast<uintptr_t>(&command_lists[slot]);
   const uintptr_t fb=reinterpret_cast<uintptr_t>(&received_fis[slot]);
   if((cl>>32)||(fb>>32)){++s.failures;continue;}
   port->clb=uint32_t(cl);port->clbu=0;port->fb=uint32_t(fb);port->fbu=0;
   port->is=0xFFFFFFFFu;port->serr=0xFFFFFFFFu;port->cmd|=(1u<<4)|(1u<<0);
   uint64_t sectors=0;
   if(identify(port,slot,&identify_data[slot],&sectors)){
    ++s.identify_success;++s.disks;disks[disk_count]={port,sectors,true};++disk_count;
   }else ++s.failures;
  }
 }
 return s;
}
extern "C" bool ahci_read_sector(uint32_t disk,uint64_t lba,void *buffer){
 if(disk>=disk_count||!disks[disk].valid||lba>=disks[disk].sectors||!buffer|| (reinterpret_cast<uintptr_t>(buffer)&511u)||reinterpret_cast<uintptr_t>(buffer)>=0x100000000ULL)return false;
 return issue(disks[disk].port,disk,0x25,lba,1,buffer);
}
extern "C" bool ahci_write_sector(uint32_t disk,uint64_t lba,const void *buffer){
 if(disk>=disk_count||!disks[disk].valid||lba>=disks[disk].sectors||!buffer|| (reinterpret_cast<uintptr_t>(buffer)&511u)||reinterpret_cast<uintptr_t>(buffer)>=0x100000000ULL)return false;
 return issue(disks[disk].port,disk,0x35,lba,1,const_cast<void*>(buffer));
}
extern "C" uint32_t ahci_disk_count(void){return disk_count;}
