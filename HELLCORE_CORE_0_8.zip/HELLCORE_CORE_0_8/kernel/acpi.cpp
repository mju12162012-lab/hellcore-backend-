#include <stdint.h>
#include "acpi.h"
namespace {
struct __attribute__((packed)) Rsdp1 { char sig[8]; uint8_t checksum; char oem[6]; uint8_t revision; uint32_t rsdt; };
struct __attribute__((packed)) Rsdp2 { Rsdp1 v1; uint32_t length; uint64_t xsdt; uint8_t ext_checksum; uint8_t reserved[3]; };
struct __attribute__((packed)) Sdt { char sig[4]; uint32_t length; uint8_t revision, checksum; char oem[6], table_id[8]; uint32_t oem_rev, creator, creator_rev; };
struct __attribute__((packed)) Madt { Sdt h; uint32_t lapic; uint32_t flags; };
struct __attribute__((packed)) Mcfg { Sdt h; uint64_t reserved; };
struct __attribute__((packed)) McfgAllocation { uint64_t base; uint16_t segment; uint8_t start_bus, end_bus; uint32_t reserved; };
uint8_t checksum(const void *ptr, uint32_t n) {
    const uint8_t *p = (const uint8_t *)ptr; uint8_t sum = 0;
    for (uint32_t i = 0; i < n; ++i) sum = (uint8_t)(sum + p[i]);
    return sum;
}
bool eq4(const char *a, const char *b) {
    for (unsigned i = 0; i < 4; ++i) if (a[i] != b[i]) return false;
    return true;
}
bool valid(const Sdt *h) {
    return h && h->length >= sizeof(Sdt) && h->length <= 0x100000 && checksum(h, h->length) == 0;
}
const Sdt *find(const Sdt *root, bool wide, const char *name) {
    if (!valid(root)) return nullptr;
    const uint32_t stride = wide ? 8 : 4;
    const uint32_t bytes = root->length - sizeof(Sdt);
    if (bytes % stride) return nullptr;
    const uint8_t *p = (const uint8_t *)root + sizeof(Sdt);
    for (uint32_t off = 0; off < bytes; off += stride) {
        uint64_t address = 0;
        for (uint32_t j = 0; j < stride; ++j) address |= (uint64_t)p[off + j] << (j * 8);
        if (!address || address >= 0x100000000ULL) continue;
        const Sdt *table = (const Sdt *)(uintptr_t)address;
        if (valid(table) && eq4(table->sig, name)) return table;
    }
    return nullptr;
}
}
extern "C" bool acpi_discover(uint64_t address, AcpiInfo *out) {
    if (!address || address >= 0x100000000ULL || !out) return false;
    const Rsdp1 *r = (const Rsdp1 *)(uintptr_t)address;
    const char signature[8] = {'R','S','D',' ','P','T','R',' '};
    for (unsigned i = 0; i < 8; ++i) if (r->sig[i] != signature[i]) return false;
    if (checksum(r, 20) != 0) return false;
    uint64_t root_addr = r->rsdt;
    bool wide = false;
    if (r->revision >= 2) {
        const Rsdp2 *r2 = (const Rsdp2 *)r;
        if (r2->length < sizeof(Rsdp2) || r2->length > 4096 || checksum(r, r2->length) != 0) return false;
        if (r2->xsdt) { root_addr = r2->xsdt; wide = true; }
    }
    if (!root_addr || root_addr >= 0x100000000ULL) return false;
    const Sdt *root = (const Sdt *)(uintptr_t)root_addr;
    if (!valid(root) || !eq4(root->sig, wide ? "XSDT" : "RSDT")) return false;
    AcpiInfo info{};
    info.revision = r->revision;
    for (unsigned i = 0; i < 6; ++i) info.oem_id[i] = r->oem[i];
    info.oem_id[6] = 0;
    info.rsdt_address = r->rsdt;
    if (r->revision >= 2) info.xsdt_address = ((const Rsdp2 *)r)->xsdt;
    const Madt *m = (const Madt *)find(root, wide, "APIC");
    if (m) {
        if (m->h.length < sizeof(Madt)) return false;
        info.has_madt = 1;
        info.lapic_address = m->lapic;
        uint32_t off = sizeof(Madt);
        while (off + 2 <= m->h.length) {
            const uint8_t *entry = (const uint8_t *)m + off;
            const uint8_t type = entry[0], len = entry[1];
            if (len < 2 || off + len > m->h.length) return false;
            if (type == 0 && len >= 8) ++info.processor_count;
            else if (type == 1 && len >= 12) ++info.ioapic_count;
            else if (type == 5 && len >= 12) {
                const uint8_t *v = entry + 4;
                info.lapic_address = (uint64_t)v[0] | ((uint64_t)v[1] << 8) | ((uint64_t)v[2] << 16) | ((uint64_t)v[3] << 24) |
                                     ((uint64_t)v[4] << 32) | ((uint64_t)v[5] << 40) | ((uint64_t)v[6] << 48) | ((uint64_t)v[7] << 56);
            } else if (type == 9 && len >= 16) ++info.processor_count;
            off += len;
        }
    }
    const Mcfg *mcfg = (const Mcfg *)find(root, wide, "MCFG");
    if (mcfg && mcfg->h.length >= sizeof(Mcfg) + sizeof(McfgAllocation)) {
        const uint32_t bytes = mcfg->h.length - sizeof(Mcfg);
        if (bytes % sizeof(McfgAllocation) == 0) {
            const auto *a = reinterpret_cast<const McfgAllocation *>(reinterpret_cast<const uint8_t *>(mcfg) + sizeof(Mcfg));
            const uint64_t span = (uint64_t(a->end_bus) - uint64_t(a->start_bus) + 1ULL) << 20;
            if (a->base && a->start_bus <= a->end_bus && a->base < 0x100000000ULL && span <= 0x100000000ULL - a->base) {
                info.has_mcfg = 1;
                info.mcfg = {a->base, a->segment, a->start_bus, a->end_bus};
            }
        }
    }
    *out = info;
    return true;
}
