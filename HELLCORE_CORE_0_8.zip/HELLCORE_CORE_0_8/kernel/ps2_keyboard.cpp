#include "ps2_keyboard.h"
namespace {
static inline uint8_t in8(uint16_t p) { uint8_t v; __asm__ __volatile__("inb %1,%0":"=a"(v):"Nd"(p)); return v; }
static inline void out8(uint16_t p,uint8_t v) { __asm__ __volatile__("outb %0,%1"::"a"(v),"Nd"(p)); }
bool wait_input_clear() { for(uint32_t i=0;i<100000;++i) if(!(in8(0x64)&2)) return true; return false; }
bool wait_output_full() { for(uint32_t i=0;i<100000;++i) if(in8(0x64)&1) return true; return false; }
bool command(uint8_t v) { if(!wait_input_clear())return false; out8(0x60,v); return wait_output_full() && in8(0x60)==0xFA; }
}
extern "C" bool ps2_keyboard_init(void) {
    if(!wait_input_clear()) return false; out8(0x64,0xAE);
    if(!wait_input_clear()) return false; out8(0x64,0x20);
    if(!wait_output_full()) return false;
    uint8_t config=in8(0x60); config|=1; config&=uint8_t(~0x10);
    if(!wait_input_clear()) return false; out8(0x64,0x60);
    if(!wait_input_clear()) return false; out8(0x60,config);
    return command(0xF4);
}
extern "C" bool ps2_keyboard_poll(uint8_t *scancode) {
    if(!scancode || !(in8(0x64)&1)) return false;
    *scancode=in8(0x60); return true;
}
