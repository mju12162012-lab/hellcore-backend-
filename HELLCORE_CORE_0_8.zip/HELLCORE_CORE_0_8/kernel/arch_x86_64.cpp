#include <stdint.h>
#include "arch_x86_64.h"
extern "C" void *isr_stub_table[32]; extern "C" void isr_default_stub(void); extern "C" void isr_timer_stub(void);
namespace {
struct __attribute__((packed)) TablePointer { uint16_t limit; uint64_t base; };
struct __attribute__((packed)) IdtEntry { uint16_t lo,sel; uint8_t ist,attr; uint16_t mid; uint32_t hi,zero; };
struct __attribute__((packed)) Tss { uint32_t reserved0; uint64_t rsp0,rsp1,rsp2; uint64_t reserved1; uint64_t ist1,ist2,ist3,ist4,ist5,ist6,ist7; uint64_t reserved2; uint16_t reserved3,iomap; };
struct Gdt { uint64_t e[5]; };
alignas(16) Gdt gdt={{0,0x00AF9A000000FFFFULL,0x00CF92000000FFFFULL,0,0}};
alignas(16) IdtEntry idt[256]; alignas(16) Tss tss{};
alignas(16) uint8_t privilege_stack[16384], double_fault_stack[16384], nmi_stack[16384], machine_check_stack[16384];
volatile uint64_t ticks=0; volatile uint32_t *lapic=nullptr;
void set_gate(uint8_t v,void *fn,uint8_t ist=0){uint64_t a=(uint64_t)fn;idt[v]={uint16_t(a),0x08,ist,uint8_t(0x8E),uint16_t(a>>16),uint32_t(a>>32),0};}
static inline void outb(uint16_t p,uint8_t v){__asm__ __volatile__("outb %0,%1"::"a"(v),"Nd"(p));}
static inline uint8_t inb(uint16_t p){uint8_t v;__asm__ __volatile__("inb %1,%0":"=a"(v):"Nd"(p));return v;}
uint64_t rdmsr(uint32_t msr){uint32_t lo,hi;__asm__ __volatile__("rdmsr":"=a"(lo),"=d"(hi):"c"(msr));return(uint64_t(hi)<<32)|lo;}
void wrmsr(uint32_t msr,uint64_t v){__asm__ __volatile__("wrmsr"::"c"(msr),"a"(uint32_t(v)),"d"(uint32_t(v>>32)));}
}
extern "C" void gdt_init(void){tss.rsp0=(uint64_t)(privilege_stack+sizeof(privilege_stack));tss.ist1=(uint64_t)(double_fault_stack+sizeof(double_fault_stack));tss.ist2=(uint64_t)(nmi_stack+sizeof(nmi_stack));tss.ist3=(uint64_t)(machine_check_stack+sizeof(machine_check_stack));tss.iomap=sizeof(Tss);uint64_t b=(uint64_t)&tss,lim=sizeof(Tss)-1;gdt.e[3]=(lim&0xffff)|((b&0xffffff)<<16)|(0x89ULL<<40)|(((lim>>16)&0xf)<<48)|(((b>>24)&0xff)<<56);gdt.e[4]=b>>32;TablePointer p{uint16_t(sizeof(gdt)-1),(uint64_t)&gdt};gdt_load(&p);tss_load();}
extern "C" void idt_init(void){for(uint16_t i=0;i<256;++i)set_gate((uint8_t)i,(void*)isr_default_stub);for(uint8_t i=0;i<32;++i)set_gate(i,isr_stub_table[i]);set_gate(8,isr_stub_table[8],1);set_gate(2,isr_stub_table[2],2);set_gate(18,isr_stub_table[18],3);set_gate(0x40,(void*)isr_timer_stub);TablePointer p{uint16_t(sizeof(idt)-1),(uint64_t)&idt};idt_load(&p);}
extern "C" bool apic_init(void){uint32_t a,b,c,d;__asm__ __volatile__("cpuid":"=a"(a),"=b"(b),"=c"(c),"=d"(d):"a"(1),"c"(0));if(!(d&(1u<<9)))return false;uint64_t base=rdmsr(0x1B);if(base&(1ULL<<10))return false;base|=(1ULL<<11);wrmsr(0x1B,base);lapic=(volatile uint32_t*)(uintptr_t)(base&0xFFFFF000ULL);lapic[0xF0/4]=0x100|0xFF;lapic[0x80/4]=0;lapic[0x320/4]=0x10000|0x40;return true;}
extern "C" bool apic_timer_start(uint32_t hz){
    if(!lapic || !hz)return false;
    lapic[0x3E0/4]=0x3;                 // divide by 16
    lapic[0x320/4]=0x10000|0x40;       // masked during calibration
    lapic[0x380/4]=0xFFFFFFFFU;
    uint8_t speaker=inb(0x61); outb(0x61,uint8_t((speaker&~0x02U)|0x01U));
    outb(0x43,0xB0); outb(0x42,0xFF); outb(0x42,0xFF); // PIT channel 2, one-shot, 65535 ticks
    outb(0x61,uint8_t((inb(0x61)&~0x02U)|0x01U));
    uint32_t spins=100000000U;
    while(!(inb(0x61)&0x20U) && --spins) __asm__ __volatile__("pause");
    uint32_t elapsed=0xFFFFFFFFU-lapic[0x390/4];
    outb(0x61,uint8_t(speaker&~0x01U));
    if(!spins || !elapsed)return false;
    uint64_t per_second=(uint64_t(elapsed)*1193182ULL)/65535ULL;
    uint64_t initial=per_second/hz;
    if(initial==0 || initial>0xFFFFFFFFULL)return false;
    lapic[0x320/4]=0x20000|0x40; // periodic mode, vector 0x40
    lapic[0x380/4]=(uint32_t)initial;
    return true;
}
extern "C" void apic_eoi(void){if(lapic)lapic[0xB0/4]=0;}
extern "C" uint64_t apic_ticks(void){return ticks;}
extern "C" void interrupt_dispatch(InterruptFrame *f){if(!f)return;if(f->vector<32){extern void kernel_exception_report(uint64_t,uint64_t,uint64_t);kernel_exception_report(f->vector,f->error_code,f->rip);}if(f->vector==0x40){ticks=ticks+1;apic_eoi();return;}apic_eoi();}
