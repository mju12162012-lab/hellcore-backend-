#include <stddef.h>
#include "e1000.h"
#include "vmm.h"

namespace {
constexpr uint32_t RingCount=32, BufferSize=2048;
struct alignas(16) TxDesc { uint64_t address; uint16_t length; uint8_t cso,cmd,status,css; uint16_t special; };
struct alignas(16) RxDesc { uint64_t address; uint16_t length; uint16_t checksum; uint8_t status,errors; uint16_t special; };
struct alignas(16) Buffer { uint8_t bytes[BufferSize]; };
static TxDesc tx_ring[RingCount]; static RxDesc rx_ring[RingCount];
static Buffer tx_buffers[RingCount],rx_buffers[RingCount];
static volatile uint32_t *regs;
static uint32_t tx_tail,rx_tail;
static bool ready;
static inline void pause_cpu(){__asm__ __volatile__("pause");}
static inline uint32_t rd(uint32_t off){return regs[off/4];}
static inline void wr(uint32_t off,uint32_t value){regs[off/4]=value;(void)regs[0x0008/4];}
static bool dma_ok(uintptr_t p,size_t n){return p<0x100000000ULL&&n<=0x100000000ULL-p;}
}
extern "C" E1000Stats e1000_probe(const PciDevice *ds,uint32_t n){
 E1000Stats s{};ready=false;regs=nullptr;
 for(uint32_t i=0;i<n;++i){const PciDevice &d=ds[i];if(d.class_code!=2||d.subclass!=0)continue;++s.controllers;
  const PciBar *b=nullptr;for(unsigned k=0;k<6;++k)if(d.bars[k].size&&!d.bars[k].is_io&&d.bars[k].assigned){b=&d.bars[k];break;}
  if(!b||b->base>=0x100000000ULL||b->size<0x6000||!pci_enable_bus_master(&d)||!vmm_mark_mmio_uc(b->base,b->size)){++s.failures;continue;}
  regs=reinterpret_cast<volatile uint32_t*>(uintptr_t(b->base));
  wr(0x0000,1u<<26);for(unsigned spin=0;spin<1000000;++spin)pause_cpu();wr(0x0000,0);
  if(rd(0x0008)==0xFFFFFFFFu){++s.failures;regs=nullptr;continue;}
  const uintptr_t txp=reinterpret_cast<uintptr_t>(tx_ring),rxp=reinterpret_cast<uintptr_t>(rx_ring);
  if(!dma_ok(txp,sizeof(tx_ring))||!dma_ok(rxp,sizeof(rx_ring))){++s.failures;regs=nullptr;continue;}
  for(uint32_t q=0;q<RingCount;++q){
   const uintptr_t tb=reinterpret_cast<uintptr_t>(&tx_buffers[q]),rb=reinterpret_cast<uintptr_t>(&rx_buffers[q]);
   if(!dma_ok(tb,BufferSize)||!dma_ok(rb,BufferSize)){++s.failures;regs=nullptr;return s;}
   tx_ring[q]={};tx_ring[q].address=tb;tx_ring[q].status=1;
   rx_ring[q]={};rx_ring[q].address=rb;
  }
  wr(0x3800,uint32_t(txp));wr(0x3804,uint32_t(txp>>32));wr(0x3808,sizeof(tx_ring));wr(0x3810,0);wr(0x3818,0);
  wr(0x2800,uint32_t(rxp));wr(0x2804,uint32_t(rxp>>32));wr(0x2808,sizeof(rx_ring));wr(0x2810,0);wr(0x2818,RingCount-1);
  wr(0x0410,10u|(8u<<10)|(6u<<20));
  wr(0x0400,(1u<<1)|(1u<<3)|(0x10u<<4)|(0x40u<<12));
  wr(0x0100,(1u<<1)|(1u<<15)|(1u<<26));
  tx_tail=0;rx_tail=0;ready=true;++s.initialized;if(rd(0x0008)&(1u<<1))++s.link_up;
 }
 return s;
}
extern "C" bool e1000_send(const void *frame,uint16_t length){
 if(!ready||!frame||!length||length>BufferSize)return false;
 TxDesc &d=tx_ring[tx_tail];for(uint32_t spin=0;spin<1000000&&!(d.status&1u);++spin)pause_cpu();if(!(d.status&1u))return false;
 const auto *src=static_cast<const uint8_t*>(frame);for(uint16_t i=0;i<length;++i)tx_buffers[tx_tail].bytes[i]=src[i];
 d.length=length;d.cso=0;d.cmd=0x0Bu;d.status=0;d.css=0;d.special=0;
 const uint32_t next=(tx_tail+1)%RingCount;wr(0x3818,next);tx_tail=next;
 for(uint32_t spin=0;spin<5000000&&!(d.status&1u);++spin)pause_cpu();return (d.status&1u)!=0;
}
extern "C" int32_t e1000_receive(void *frame,uint16_t capacity){
 if(!ready||!frame||!capacity)return -1;RxDesc &d=rx_ring[rx_tail];if(!(d.status&1u))return 0;
 const uint16_t length=d.length;if(d.errors||length>capacity){d.status=0;wr(0x2818,rx_tail);rx_tail=(rx_tail+1)%RingCount;return -1;}
 auto *dst=static_cast<uint8_t*>(frame);for(uint16_t i=0;i<length;++i)dst[i]=rx_buffers[rx_tail].bytes[i];
 d.status=0;d.length=0;wr(0x2818,rx_tail);rx_tail=(rx_tail+1)%RingCount;return length;
}
