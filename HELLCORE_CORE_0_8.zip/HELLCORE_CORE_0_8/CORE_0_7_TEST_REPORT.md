# HELLCORE CORE 0.7 — Build and validation report

Date: 2026-11-15
Target: x86-64 freestanding C++20 kernel, native UEFI PE32+ loader

## Implemented

- Retained CORE 0.6 AHCI single-sector DMA read/write prototype and E1000 32-entry TX/RX descriptor-ring prototype.
- Replaced xHCI halt/reset-only probe with controller halt/reset, DCBAA, command ring, event ring, ERST, runtime interrupter/ERDP setup for polling, controller run-state check, connected-port detection, and Enable Slot command submission/completion polling.
- Expanded xHCI serial counters for running controllers, connected ports, enabled slots, command timeouts and failures.
- Updated UEFI boot validation marker to CORE 0.7.

## Build and host tests actually run

Command:

```sh
make clean all efi esp check
nm -u build/kernel.elf
```

Results:

- Freestanding kernel compilation and static ELF64 link: PASS.
- Native UEFI loader compilation and PE32+ link: PASS.
- EFI system partition directory generation: PASS.
- ACPI parser tests: PASS.
- PCI resource allocator and PCI class tests: PASS.
- PMM host tests: PASS.
- ELF and UEFI PE32+ format/ABI checks: PASS.
- `nm -u build/kernel.elf`: no undefined symbols.

## QEMU/UEFI runtime validation

**BLOCKED — NOT RUN.** The environment does not contain `qemu-system-x86_64` or OVMF firmware. Earlier package installation attempts timed out. No QEMU process ran and no firmware-to-kernel serial log was produced. No AHCI, E1000 or xHCI runtime behavior is claimed as verified.

## xHCI limitations

- Enable Slot is the furthest completed command; device contexts are not allocated or populated.
- No Address Device command, endpoint contexts, control transfer ring, USB descriptor requests, full USB enumeration, hubs, HID or hotplug.
- Event processing is polling-only; no xHCI interrupt routing.
- Controller/device DMA remains restricted to identity-mapped physical addresses below 4 GiB. No DMA allocator or IOMMU support.
- The shared static xHCI ring storage is currently suitable only for a single initialized controller; multi-controller isolation is not implemented.
- xHCI command/event sequencing has compiled but has not been exercised against QEMU or physical hardware.

## Inherited driver limitations

- AHCI is a synchronous single-sector DMA prototype; no multi-sector batching, NCQ, interrupt-driven completion, robust timeout recovery, hotplug, general DMA allocator, block layer or filesystem.
- E1000 has basic descriptor-ring TX/RX APIs but no QEMU/physical runtime test, interrupt path, robust error recovery, broad revision support or network stack.
- PCI BAR relocation is not automatic because validated host-bridge apertures are not discovered. Current MMIO/DMA assumptions remain below 4 GiB.

## Next validation gates

1. Provide an environment with QEMU x86-64 and OVMF; run `scripts/validate-boot.sh` and retain the actual COM1 log.
2. Verify xHCI reset, Run state, connected-port status and Enable Slot completion with QEMU `qemu-xhci` and a USB keyboard.
3. Implement device contexts, Address Device, control endpoint transfers and descriptor parsing; then enumerate a USB keyboard.
4. Test AHCI sector write/readback only against a disposable QEMU disk image.
5. Verify E1000 TX/RX descriptor ownership and packet delivery with QEMU packet capture or a loopback peer.

A clean compile and host tests do not establish successful UEFI boot or working hardware data paths.
