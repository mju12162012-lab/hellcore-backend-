# HELLCORE CORE 0.3 — Build and verification report

Date: 2026-11-15  
Target: freestanding x86-64 kernel + native UEFI loader

## Implemented

- Four-level x86-64 page-table root creation and CR3 activation.
- Initial identity map of physical addresses 0–4 GiB using 2 MiB pages.
- 4 KiB page mapping API; splits an existing 2 MiB mapping into a page table on demand.
- Uncacheable identity mappings for the conventional xAPIC and I/O APIC MMIO windows.
- Physical-frame bitmap allocator covering the first 4 GiB, with frame release and double-free/reserved-frame rejection.
- GDT with 64-bit TSS descriptor; independent privilege-transition stack plus dedicated IST stacks for double fault, NMI, and machine check.
- APIC detection and xAPIC enablement; x2APIC mode is currently rejected rather than incorrectly treating its MSR interface as MMIO.
- Local APIC periodic timer setup calibrated against PIT channel 2, targeting 100 Hz.
- Timer interrupt vector, EOI handling, and PIC masking before enabling interrupts.
- CORE 0.3 serial initialization diagnostics.

## Build and tests actually run

Commands:

```sh
make clean all efi esp check
file build/kernel.elf build/BOOTX64.EFI build/libhellcore_uefi.lib
readelf -h build/kernel.elf
nm -u build/kernel.elf
```

Results:

- Freestanding C++20 kernel compilation: PASS.
- x86-64 ELF64 static kernel link: PASS.
- UEFI loader compilation: PASS.
- PE32+ x86-64 EFI application link: PASS.
- Native UEFI static library archive: PASS.
- ESP directory layout creation: PASS.
- ELF format/symbol checks: PASS.
- Host physical allocator tests, including free, double-free rejection, and reserved-frame rejection: PASS.
- UEFI PE32+ format, subsystem, entry point, relocation and ABI checks: PASS.
- Undefined kernel symbols (`nm -u`): none reported.

## Not verified

- QEMU executable is not installed in the execution environment.
- OVMF firmware image is not installed/discoverable in the execution environment.
- Therefore the requested first successful QEMU boot has **not** been achieved or claimed.
- No serial log from firmware/kernel boot exists.
- No physical hardware boot has been performed.
- APIC/PIT calibration and interrupt delivery are compiled but not runtime-tested.

## Scope and constraints

- The current VMM identity maps only the first 4 GiB. It is a bootstrap address space, not a complete virtual-memory subsystem.
- PMM metadata covers 4 GiB and does not yet track arbitrary reserved ranges beyond what the UEFI memory types exclude.
- The xAPIC MMIO path is implemented; x2APIC mode is not.
- The PIT-calibrated LAPIC timer is a prototype and needs runtime validation on QEMU/OVMF and physical machines.
- IST stacks are dedicated for #DF, NMI, and #MC. Other exceptions currently use the active kernel stack.
- No scheduler, SMP startup, userspace, drivers, filesystem, graphics, networking, installer, Secure Boot, or ARM64 support is claimed.

A successful build is not evidence of a successful boot. CORE 0.3 remains an unboot-tested kernel prototype until a QEMU/OVMF run produces and captures the expected serial initialization log.
