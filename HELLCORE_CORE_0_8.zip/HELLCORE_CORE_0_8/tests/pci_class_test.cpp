#include <cstdio>
#include <cstring>
#include "pci.h"
extern "C" bool vmm_mark_mmio_uc(uint64_t, uint64_t) { return true; }
int main() {
    if(std::strcmp(pci_class_name(0x03,0x00),"display") ||
       std::strcmp(pci_class_name(0x02,0x00),"network") ||
       std::strcmp(pci_class_name(0x01,0x06),"mass-storage") ||
       std::strcmp(pci_class_name(0x0C,0x03),"usb-controller") ||
       std::strcmp(pci_class_name(0x04,0x01),"multimedia-audio")) return 1;
    std::puts("PCI class identification tests passed: display, network, storage, USB, audio");
    return 0;
}
