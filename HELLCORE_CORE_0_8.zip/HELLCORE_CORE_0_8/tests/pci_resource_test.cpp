#include <assert.h>
#include <stdint.h>
#include "pci_resources.h"
int main() {
    PciResourcePool low{};
    pci_resource_pool_init(&low,0x80000000ULL,0x1000000ULL);
    PciResourceRange reserved[2]={{0x80000000ULL,0x10000ULL},{0x80040000ULL,0x10000ULL}};
    uint64_t a=0;
    assert(pci_resource_allocate(&low,0x20000ULL,0x10000ULL,reserved,2,&a));
    assert(a==0x80010000ULL);
    uint64_t b=0;
    assert(pci_resource_allocate(&low,0x100000ULL,0x100000ULL,reserved,2,&b));
    assert((b&0xFFFFFULL)==0);
    assert(!pci_resource_allocate(&low,0x2000000ULL,0x1000ULL,reserved,2,&b));
    assert(pci_resource_ranges_overlap({0x1000,0x1000},{0x1800,0x1000}));
    assert(!pci_resource_ranges_overlap({0x1000,0x1000},{0x2000,0x1000}));
    PciResourcePool high{};
    pci_resource_pool_init(&high,0x100000000ULL,0x40000000ULL);
    uint64_t bar64=0;
    assert(pci_resource_allocate(&high,0x200000ULL,0x200000ULL,nullptr,0,&bar64));
    assert(bar64==0x100000000ULL); // 64-bit BAR aperture above 4 GiB
}
