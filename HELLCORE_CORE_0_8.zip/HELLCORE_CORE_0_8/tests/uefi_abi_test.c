#include <stddef.h>
#include "uefi/uefi_file.h"
_Static_assert(sizeof(EFI_TABLE_HEADER) == 24, "UEFI table header layout");
_Static_assert(offsetof(EFI_BOOT_SERVICES, AllocatePages) == 40, "BootServices AllocatePages offset");
_Static_assert(offsetof(EFI_BOOT_SERVICES, GetMemoryMap) == 56, "BootServices GetMemoryMap offset");
_Static_assert(offsetof(EFI_BOOT_SERVICES, AllocatePool) == 64, "BootServices AllocatePool offset");
_Static_assert(offsetof(EFI_BOOT_SERVICES, HandleProtocol) == 152, "BootServices HandleProtocol offset");
_Static_assert(offsetof(EFI_BOOT_SERVICES, ExitBootServices) == 232, "BootServices ExitBootServices offset");
_Static_assert(offsetof(EFI_SYSTEM_TABLE, BootServices) == 96, "SystemTable BootServices offset");
_Static_assert(offsetof(EFI_FILE_PROTOCOL, Open) == 8, "FileProtocol Open offset");
_Static_assert(offsetof(EFI_FILE_PROTOCOL, Read) == 32, "FileProtocol Read offset");
_Static_assert(offsetof(EFI_FILE_PROTOCOL, GetInfo) == 64, "FileProtocol GetInfo offset");
_Static_assert(offsetof(EFI_LOADED_IMAGE_PROTOCOL, DeviceHandle) == 24, "LoadedImage DeviceHandle offset");
_Static_assert(offsetof(EFI_SIMPLE_FILE_SYSTEM_PROTOCOL, OpenVolume) == 8, "SimpleFS OpenVolume offset");
int main(void) { return 0; }
