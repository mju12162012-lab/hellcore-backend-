#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include "acpi.h"
#pragma pack(push,1)
struct Rsdp1 { char sig[8]; uint8_t checksum; char oem[6]; uint8_t revision; uint32_t rsdt; };
struct Sdt { char sig[4]; uint32_t length; uint8_t revision,checksum; char oem[6],table[8]; uint32_t oemrev,creator,creatorrev; };
struct Madt { Sdt h; uint32_t lapic,flags; uint8_t cpu[8],ioapic[12]; };
struct Mcfg { Sdt h; uint64_t reserved; uint64_t base; uint16_t segment; uint8_t start_bus,end_bus; uint32_t reserved2; };
struct Rsdp2 { Rsdp1 v1; uint32_t length; uint64_t xsdt; uint8_t ext; uint8_t reserved[3]; };
#pragma pack(pop)
static void fix(void*p,uint32_t n,uint32_t off){uint8_t*b=(uint8_t*)p;b[off]=0;uint8_t s=0;for(uint32_t i=0;i<n;++i)s=(uint8_t)(s+b[i]);b[off]=(uint8_t)(0-s);}
int main(){
 uint8_t *arena=(uint8_t*)mmap(nullptr,4096,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_32BIT,-1,0);if(arena==MAP_FAILED)return 3;memset(arena,0,4096);auto*r=(Rsdp2*)arena;auto*root=(Sdt*)(arena+64);auto*m=(Madt*)(arena+128);auto*mcfg=(Mcfg*)(arena+256);uint64_t*entries=(uint64_t*)(arena+sizeof(Sdt)+64);
 memcpy(r->v1.sig,"RSD PTR ",8);memcpy(r->v1.oem,"HCORE ",6);r->v1.revision=2;r->length=sizeof(Rsdp2);r->xsdt=(uintptr_t)root;fix(r,20,8);fix(r,sizeof(Rsdp2),32);
 memcpy(root->sig,"XSDT",4);root->length=sizeof(Sdt)+16;entries[0]=(uintptr_t)m;entries[1]=(uintptr_t)mcfg;fix(root,root->length,9);
 memcpy(m->h.sig,"APIC",4);m->h.length=sizeof(Madt);m->lapic=0xFEE00000;m->cpu[0]=0;m->cpu[1]=8;m->cpu[2]=1;m->ioapic[0]=1;m->ioapic[1]=12;fix(m,m->h.length,9);
 memcpy(mcfg->h.sig,"MCFG",4);mcfg->h.length=sizeof(Mcfg);mcfg->base=0xE0000000ULL;mcfg->segment=0;mcfg->start_bus=0;mcfg->end_bus=255;fix(mcfg,mcfg->h.length,9);fix(root,root->length,9);
 AcpiInfo info{};if(!acpi_discover((uintptr_t)r,&info)||!info.has_madt||info.lapic_address!=0xFEE00000||info.processor_count!=1||info.ioapic_count!=1||!info.has_mcfg||info.mcfg.base_address!=0xE0000000ULL||info.mcfg.end_bus!=255)return 1;
 m->h.checksum++;if(!acpi_discover((uintptr_t)r,&info)||info.has_madt)return 2;
 puts("ACPI parser tests passed: XSDT, MADT, MCFG/PCIe ECAM range, CPU/IOAPIC entries, checksum rejection");munmap(arena,4096);return 0;
}
