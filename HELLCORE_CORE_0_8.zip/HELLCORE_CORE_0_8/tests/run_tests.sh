#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
CXX=${CXX:-g++}
TMP=${TMPDIR:-/tmp}/hellcore-pmm-test-$$
trap 'rm -f "$TMP"' EXIT
"$CXX" -std=c++20 -Wall -Wextra -Werror -I"$ROOT/include" \
  "$ROOT/kernel/pmm.cpp" "$ROOT/tests/pmm_test.cpp" -o "$TMP"
"$TMP"
