#!/usr/bin/env sh
set -eu
ELF="${1:-build/kernel.elf}"
command -v readelf >/dev/null 2>&1 || { echo "readelf is required" >&2; exit 2; }
[ -f "$ELF" ] || { echo "Missing kernel ELF: $ELF" >&2; exit 2; }
readelf -h "$ELF" | grep -q 'ELF64'
readelf -h "$ELF" | grep -q 'Advanced Micro Devices X86-64'
readelf -sW "$ELF" | grep -q 'kernel_main'
readelf -sW "$ELF" | grep -q 'gdt_init'
readelf -sW "$ELF" | grep -q 'idt_init'
readelf -sW "$ELF" | grep -q 'pmm_allocate_frame'
readelf -sW "$ELF" | grep -q 'pmm_free_frame'
readelf -sW "$ELF" | grep -q 'vmm_init'
readelf -sW "$ELF" | grep -q 'vmm_map_page'
readelf -sW "$ELF" | grep -q 'apic_timer_start'
echo "PASS: ELF64 x86-64 kernel image, virtual memory, PMM release, and APIC timer symbols verified"
