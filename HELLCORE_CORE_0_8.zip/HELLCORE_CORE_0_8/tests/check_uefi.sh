#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
EFI="$ROOT/build/BOOTX64.EFI"
LIB="$ROOT/build/libhellcore_uefi.lib"
[ -s "$EFI" ] || { echo "FAIL: missing EFI application" >&2; exit 1; }
[ -s "$LIB" ] || { echo "FAIL: missing HELLCORE UEFI support library" >&2; exit 1; }
file "$EFI" | grep -q 'PE32+ executable for EFI (application), x86-64' || { echo "FAIL: incorrect EFI image format" >&2; exit 1; }
objdump -p "$EFI" | grep -q 'Subsystem.*EFI application' || { echo "FAIL: PE subsystem is not EFI application" >&2; exit 1; }
objdump -p "$EFI" | grep -Eq 'Entry 5 [0-9a-fA-F]{16} [0-9a-fA-F]{8} Base Relocation Directory' || { echo "FAIL: EFI image has no base-relocation directory" >&2; exit 1; }
objdump -p "$EFI" | grep -q 'AddressOfEntryPoint.*0000000000000000' && { echo "FAIL: missing EFI entry point" >&2; exit 1; }
if ! objdump -p "$EFI" | grep -Eq 'Entry 1 0000000000000000 00000000 Import Directory'; then
  echo "FAIL: EFI image unexpectedly imports host runtime libraries" >&2; exit 1
fi
cc -std=c11 -Wall -Wextra -Werror -I"$ROOT/include" "$ROOT/tests/uefi_abi_test.c" -o "$ROOT/build/uefi_abi_test"
"$ROOT/build/uefi_abi_test"
echo "PASS: UEFI PE32+ application format, EFI subsystem, entry point, no host imports, SDK ABI layouts"
