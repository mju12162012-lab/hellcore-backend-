#include <cassert>
#include <cstdint>
#include <cstdio>
#include "boot_info.h"
#include "pmm.h"

struct __attribute__((packed)) TestEfiDescriptor {
    uint32_t type;
    uint32_t padding;
    uint64_t physical_start;
    uint64_t virtual_start;
    uint64_t number_of_pages;
    uint64_t attribute;
};

int main() {
    TestEfiDescriptor map[2]{};
    map[0].type = 7; // EFI conventional memory
    map[0].physical_start = 0x100000;
    map[0].number_of_pages = 4;
    map[1].type = 0; // reserved memory must not be allocated
    map[1].physical_start = 0x200000;
    map[1].number_of_pages = 8;

    HellcoreBootInfo boot{};
    boot.magic = HELLCORE_BOOT_INFO_MAGIC;
    boot.memory_map_address = reinterpret_cast<uint64_t>(&map[0]);
    boot.memory_map_size = sizeof(map);
    boot.memory_descriptor_size = sizeof(TestEfiDescriptor);

    assert(pmm_init(&boot));
    PmmStats stats = pmm_stats();
    assert(stats.conventional_pages == 4);
    assert(stats.conventional_bytes == 4 * 4096);
    assert(stats.highest_address == 0x104000);
    assert(pmm_allocate_frame() == 0x100000);
    assert(pmm_allocate_frame() == 0x101000);
    stats = pmm_stats();
    assert(stats.conventional_pages == 2);
    assert(stats.conventional_bytes == 2 * 4096);
    assert(pmm_allocate_frame() == 0x102000);
    assert(pmm_allocate_frame() == 0x103000);
    assert(pmm_allocate_frame() == 0);
    assert(pmm_free_frame(0x101000));
    assert(!pmm_free_frame(0x101000));
    assert(!pmm_free_frame(0x200000));
    assert(pmm_allocate_frame() == 0x101000);

    assert(!pmm_init(nullptr));
    std::puts("PASS: physical memory manager descriptor parsing and frame allocation");
    return 0;
}
