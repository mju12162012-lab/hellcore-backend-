#include "uefi/hellcore_uefi_lib.h"
void hc_uefi_print(EFI_SYSTEM_TABLE *st, const char *ascii) {
    if (!st || !st->ConOut || !st->ConOut->OutputString) return;
    CHAR16 line[256];
    UINTN n = 0;
    while (*ascii) {
        if (n >= 254) { line[n] = 0; st->ConOut->OutputString(st->ConOut, line); n = 0; }
        line[n++] = (UINT8)*ascii++;
    }
    line[n] = 0;
    st->ConOut->OutputString(st->ConOut, line);
}
void hc_memzero(void *dst, UINTN size) {
    UINT8 *p = (UINT8*)dst;
    for (UINTN i = 0; i < size; ++i) p[i] = 0;
}
void hc_memcpy(void *dst, const void *src, UINTN size) {
    UINT8 *d = (UINT8*)dst; const UINT8 *s = (const UINT8*)src;
    for (UINTN i = 0; i < size; ++i) d[i] = s[i];
}
