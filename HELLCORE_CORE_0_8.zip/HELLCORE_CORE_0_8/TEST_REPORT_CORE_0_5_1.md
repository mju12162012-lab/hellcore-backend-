# HELLCORE CORE 0.5.1 — Build and validation report

Date: 2026-11-15
Target: x86-64, freestanding C++20 kernel, UEFI PE32+ loader

## Implemented in source

- PCI enumeration retains discovered device descriptors for driver probing.
- PCI BAR probing covers endpoint and PCI-to-PCI bridge header layouts.
- Resource-pool allocator supports power-of-two alignment, reserved-range avoidance, overflow checks, and collision rejection.
- Explicit BAR assignment API handles I/O BARs, 32-bit MMIO BARs, and 64-bit MMIO BARs (including apertures above 4 GiB). The API requires caller-supplied resource pools and reserved ranges.
- Explicit type-1 bridge-window programming API handles I/O, non-prefetchable memory, and 64-bit prefetchable windows.
- AHCI controller/port bring-up and ATA IDENTIFY command path using statically allocated aligned DMA structures below 4 GiB.
- E1000 controller reset and link-state inspection.
- xHCI controller halt/reset validation.
- Existing PS/2 polling keyboard driver and COM1 serial diagnostics remain.
- QEMU profile now includes q35, AHCI, E1000, qemu-xhci and USB keyboard devices.
- `scripts/validate-boot.sh` rebuilds, runs host checks, launches QEMU/OVMF, and checks serial startup markers.

## Build and host-side test results

Executed from the source root:

```sh
make clean all efi esp check
nm -u build/kernel.elf
scripts/validate-boot.sh
```

Results:

- Kernel compilation and static ELF64 link: PASS.
- UEFI loader compilation and PE32+ link: PASS.
- ESP directory creation: PASS.
- ACPI parser host tests (XSDT, MADT, MCFG, checksum rejection): PASS.
- PCI class identification tests: PASS.
- PCI resource allocator tests (alignment, reserved-range collisions, overflow/insufficient capacity, >4-GiB aperture): PASS.
- PMM host tests: PASS.
- ELF checks: PASS.
- UEFI PE32+ format/subsystem/entry/ABI checks: PASS.
- `nm -u build/kernel.elf`: no undefined symbols.

## UEFI boot validation

**BLOCKED — NOT RUN.** `scripts/validate-boot.sh` exited with status 2 and reported:

```text
BOOT BLOCKED: qemu-system-x86_64 is not installed. Install qemu-system-x86 and ovmf, then rerun.
```

An earlier attempt to install `qemu-system-x86` and `ovmf` with Debian `apt-get update` / `apt-get install` timed out. No QEMU process ran, no OVMF firmware was available, and no serial boot log was produced. Therefore no successful UEFI boot is claimed.

## Not yet runtime-verified / remaining engineering work

- PCI BAR assignment and bridge-window programming are compiled APIs with host-side allocator tests; they have not been exercised against emulated or physical PCI configuration space. The kernel intentionally does not guess host-bridge apertures or reassign firmware resources at boot.
- AHCI IDENTIFY, E1000 reset/link inspection, xHCI halt/reset, PS/2 input and APIC behavior have not been runtime-tested in QEMU or on physical hardware.
- AHCI is not yet a complete block device: no queued I/O, filesystem, DMA allocator, or block layer.
- E1000 has no RX/TX descriptor rings or packet path; no network stack.
- xHCI has no slot/context setup, transfer rings, USB enumeration, or USB HID driver.
- Current VMM MMIO mapping and these initial drivers are limited to device MMIO below 4 GiB, although the resource allocator can represent 64-bit BAR apertures above 4 GiB.
- PCIe ECAM currently handles segment 0 and a single MCFG allocation below 4 GiB.

## Repeatable boot procedure

On a Debian host with QEMU and OVMF installed:

```sh
sudo apt-get update
sudo apt-get install qemu-system-x86 ovmf
./scripts/validate-boot.sh
```

The script expects the kernel to print `HELLCORE CORE 0.5 initialization complete` and driver/PCI serial markers before treating the timed QEMU run as a successful startup test.
